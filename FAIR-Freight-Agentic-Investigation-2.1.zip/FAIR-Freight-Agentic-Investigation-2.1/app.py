"""F.A.I.R. 2.1 — Freight Agentic Investigation & Resolution demo application."""
from __future__ import annotations

import json
from typing import Any

import pandas as pd
import plotly.express as px
import streamlit as st

from fair import database as db
from fair.agents import AGENT_NAMES
from fair.policy import ALLOWED_ACTIONS
from fair.workflow import WorkflowController

st.set_page_config(
    page_title="F.A.I.R. 2.1 | Freight Exception Intelligence",
    page_icon="🚚",
    layout="wide",
    initial_sidebar_state="expanded",
)

st.markdown(
    """
    <style>
      .main-header {font-size: 2.1rem; font-weight: 800; letter-spacing: -0.04em; color: #182b49;}
      .subtle {color: #64748b;}
      .section-title {font-size: 1.12rem; font-weight: 750; margin-top: .6rem; color: #203252;}
      div[data-testid="stMetric"] {background: linear-gradient(145deg, #ffffff, #f7faff); border: 1px solid #dfe7f3; padding: 13px 15px; border-radius: 14px; box-shadow: 0 1px 2px rgba(24,43,73,.04);}
      .stTabs [data-baseweb="tab-list"] {gap: 10px;}
      .small-label {font-size: .82rem; color: #64748b;}
      .agent-caption {font-size: .78rem; line-height: 1.25rem; color: #64748b;}
      section[data-testid="stSidebar"] {border-right: 1px solid #e2e8f0;}
      div[data-testid="stVerticalBlockBorderWrapper"] {border-radius: 14px;}
    </style>
    """,
    unsafe_allow_html=True,
)

db.init_db()

# ---------------------------- Session state ----------------------------
if "selected_case" not in st.session_state:
    st.session_state.selected_case = None
if "last_run_id" not in st.session_state:
    st.session_state.last_run_id = None

# ------------------------------- Sidebar -------------------------------
st.sidebar.markdown("<div class='main-header'>F.A.I.R. 2.1</div>", unsafe_allow_html=True)
st.sidebar.caption("Freight Agentic Investigation & Resolution")
st.sidebar.caption("Five-agent workflow · Evidence-first · Human oversight")
st.sidebar.markdown("---")
page = st.sidebar.radio(
    "Workspace",
    ["Exception Queue", "Investigation Console", "Resolution & Approval", "Operations Dashboard", "Audit & Compliance"],
    label_visibility="collapsed",
)
st.sidebar.markdown("---")
st.sidebar.markdown("**Agent runtime**")
llm_mode_ui = st.sidebar.radio(
    "Agent mode",
    ["Offline deterministic", "Ollama local LLM"],
    help="Ollama may suggest a tool order and resolution candidate. The independent Critic and deterministic policy checks control acceptance and escalation.",
)
llm_mode = "ollama" if llm_mode_ui == "Ollama local LLM" else "offline"
model_name = st.sidebar.text_input("Ollama model", "llama3.2", disabled=llm_mode != "ollama")
fault_ui = st.sidebar.selectbox(
    "Demo fault injection",
    ["None", "Omit liability cap", "Wrong amount", "Invalid policy reference"],
    help="Simulates one common agent mistake on attempt one, so the Critic can catch it. Use the high-value damage case to demo the cap check.",
)
fault = {"None": "none", "Omit liability cap": "omitted_cap", "Wrong amount": "wrong_amount", "Invalid policy reference": "invalid_policy"}[fault_ui]
with st.sidebar.expander("The five agents", expanded=False):
    st.markdown("1. **Triage Agent** — classify and prioritize")
    st.markdown("2. **Investigator Agent** — create the evidence plan")
    st.markdown("3. **Evidence Collector Agent** — retrieve and validate sources")
    st.markdown("4. **Resolver Agent** — propose a policy-constrained action")
    st.markdown("5. **Critic Agent** — independently validate the proposal")
st.sidebar.caption("All cases and evidence are synthetic. No real carrier queries, payments, or external actions are executed.")


def fmt_money(value: Any) -> str:
    try:
        return f"${float(value):,.2f}"
    except (TypeError, ValueError):
        return "—"


def render_trace(ctx: dict[str, Any]) -> None:
    trace = ctx.get("trace", [])
    if not trace:
        st.info("No trace events are recorded for this run.")
        return
    for index, event in enumerate(trace, start=1):
        agent = event.get("agent", "Agent")
        status = str(event.get("status", "INFO")).upper()
        icon = "✅" if status in {"SUCCESS", "PASS"} else "⚠️" if status in {"WARN", "INFO"} else "❌" if status in {"ERROR", "FAIL"} else "🔎"
        details = event.get("details", {})
        if isinstance(details, str):
            try:
                details = json.loads(details)
            except json.JSONDecodeError:
                details = {"details": details}
        label = f"{icon} {index}. {agent} — {event.get('event_type', 'EVENT')} · {status}"
        with st.expander(label, expanded=index == len(trace)):
            st.caption(f"{event.get('timestamp', 'Timestamp unavailable')} · run {str(event.get('run_id', ctx.get('run_id', '')))[0:8]}")
            if details:
                st.json(details, expanded=False)
            if event.get("event_hash"):
                st.caption(f"Audit hash: `{event['event_hash']}`")


def render_case_header(ctx: dict[str, Any]) -> None:
    case = ctx["case"]
    ship = ctx["shipment"]
    st.markdown(f"### {case['case_id']} · {case['exception_type'].replace('_', ' ').title()}")
    a, b, c, d, e = st.columns(5)
    a.metric("Severity", case["severity"])
    b.metric("Workflow status", ctx.get("status", "—").replace("_", " ").title())
    c.metric("Shipment", ship["shipment_id"])
    d.metric("Cargo value", fmt_money(ship["cargo_value"]))
    e.metric("Critic verdict", ctx.get("critic_verdict", "PENDING"))
    st.caption(f"{ship['origin']} → {ship['destination']} · {ship['carrier_id']} · customer tier {ship['customer_tier']}")
    triage = ctx.get("triage", {})
    if triage:
        st.info(f"Triage priority: **{triage.get('priority', '—')}** · score {triage.get('priority_score', '—')}/100 · {triage.get('rationale', '')}")


def render_agent_pipeline(ctx: dict[str, Any]) -> None:
    """Show the five agents only; controller routing/approval is deliberately separate."""
    status_map = ctx.get("agent_status", {})
    descriptions = {
        "Triage Agent": "Classify · prioritize",
        "Investigator Agent": "Plan evidence retrieval",
        "Evidence Collector Agent": "Retrieve · verify sources",
        "Resolver Agent": "Recommend under policy",
        "Critic Agent": "Independently validate",
    }
    visual = {
        "PENDING": ("⏳", "Pending"),
        "RUNNING": ("🔵", "Running"),
        "COMPLETED": ("✅", "Complete"),
        "COMPLETED_WITH_FLAGS": ("⚠️", "Complete · flagged"),
        "COMPLETED_WITH_GAPS": ("⚠️", "Complete · gaps"),
        "COMPLETED_WITH_FAILURES": ("❌", "Checks failed"),
        "FAILED": ("❌", "Failed"),
        "SKIPPED": ("—", "Skipped safely"),
    }
    st.markdown("#### Five-agent workflow")
    cols = st.columns(5)
    for idx, (col, name) in enumerate(zip(cols, AGENT_NAMES), start=1):
        status = status_map.get(name, "PENDING")
        icon, label = visual.get(status, ("🔎", status.title()))
        with col.container(border=True):
            st.markdown(f"**{idx:02d} · {name}**")
            st.markdown(f"{icon} **{label}**")
            st.caption(descriptions[name])
    st.caption("Only these five components are agents. Bounded retry, terminal routing and human approval are workflow controls, not additional agents.")


def load_context_for_case(case_id: str) -> dict[str, Any] | None:
    latest = db.latest_investigation(case_id)
    if not latest:
        return None
    return latest["result"]


def render_resolution(ctx: dict[str, Any]) -> None:
    resolution = ctx.get("resolution")
    if not resolution:
        st.warning("No automated resolution was produced because critical evidence is missing. The case is waiting for human review.")
        if ctx.get("evidence_gaps"):
            st.write("**Evidence gaps:** " + ", ".join(ctx["evidence_gaps"]))
        return
    cols = st.columns(5)
    cols[0].metric("Proposed action", resolution.get("action", "—").replace("_", " ").title())
    cols[1].metric("Estimated amount", fmt_money(resolution.get("amount", 0)))
    cols[2].metric("Evidence-derived confidence", f"{float(resolution.get('confidence', 0)):.0%}")
    cols[3].metric("Resolver attempts", str(ctx.get("attempt", 0)))
    cols[4].metric("Effective cap", fmt_money(resolution.get("effective_cap", 0)))
    st.write(f"**Root cause:** {resolution.get('root_cause', '—')}")
    st.write(f"**Rationale:** {resolution.get('rationale', '—')}")
    st.write("**Policy references:** " + (", ".join(resolution.get("policy_references", [])) or "None"))
    for note in resolution.get("notes", []):
        st.caption(f"ℹ️ {note}")
    if ctx.get("human_review_reasons"):
        st.warning("**Human review required**\n\n" + "\n".join(f"- {reason}" for reason in ctx["human_review_reasons"]))


def render_evidence(ctx: dict[str, Any]) -> None:
    bundle = ctx.get("bundle", [])
    if not bundle:
        st.info("Evidence collection did not run or returned no items.")
        return
    rows = [{"Tool": x.get("tool_name"), "Status": x.get("status"), "Critical": "Yes" if x.get("critical") else "No",
             "Attempts": x.get("attempts", 0), "Source": x.get("source"), "Finding": x.get("finding")} for x in bundle]
    st.dataframe(pd.DataFrame(rows), use_container_width=True, hide_index=True)
    quality = ctx.get("evidence_quality", {})
    gap_ratio = float(ctx.get("gap_ratio", 0))
    completeness = float(quality.get("completeness", max(0.0, 1.0 - gap_ratio)))
    st.caption(f"Evidence gap ratio: {gap_ratio:.0%} · completeness: {completeness:.0%}. Evidence comes from local synthetic fixtures and is not live carrier data.")
    st.progress(min(1.0, max(0.0, completeness)))
    with st.expander("Inspect source details", expanded=False):
        for item in bundle:
            with st.expander(f"{item.get('tool_name')} · {item.get('status')}", expanded=False):
                st.write(item.get("purpose", ""))
                st.json(item.get("details", {}), expanded=False)


def render_critic(ctx: dict[str, Any]) -> None:
    verdict = ctx.get("critic_verdict", "PENDING")
    if verdict == "PASS":
        st.success(f"Critic validation passed on attempt {ctx.get('attempt', 0)}.")
    elif verdict == "FAIL":
        st.error("Critic could not validate the proposal within the retry limit. Human review is required.")
    else:
        st.info("The Critic did not run because the workflow escalated before resolution.")
    checks = ctx.get("critic_checks", [])
    if checks:
        st.dataframe(pd.DataFrame([{"Check": c["check"], "Result": "✅ PASS" if c["passed"] else "❌ FAIL", "Details": c["detail"]} for c in checks]),
                     use_container_width=True, hide_index=True)
    if ctx.get("rejected_attempts"):
        with st.expander("Rejected attempts and revision feedback", expanded=True):
            for rejected in ctx["rejected_attempts"]:
                st.markdown(f"**Attempt {rejected['attempt']}** · rejected amount {fmt_money(rejected.get('amount'))}")
                for note in rejected.get("failed_checks", []):
                    st.write(f"- {note}")

# ============================ PAGE 1: QUEUE ============================
if page == "Exception Queue":
    st.markdown("<div class='main-header'>Exception Queue</div>", unsafe_allow_html=True)
    st.caption("Prioritize freight exceptions and start a traceable, exception-specific investigation.")
    cases_all = db.list_cases()
    qm1, qm2, qm3, qm4 = st.columns(4)
    qm1.metric("Total cases", len(cases_all))
    qm2.metric("Critical cases", sum(1 for x in cases_all if x["severity"] == "CRITICAL"))
    qm3.metric("Open / in progress", sum(1 for x in cases_all if x["status"] in {"OPEN", "IN_PROGRESS"}))
    qm4.metric("Escalated", sum(1 for x in cases_all if x["status"] == "ESCALATED"))
    f1, f2, f3, f4 = st.columns([1.25, 1.0, 1.15, 1.8])
    type_filter = f1.selectbox("Exception type", ["All"] + sorted({x["exception_type"] for x in cases_all}))
    sev_filter = f2.selectbox("Severity", ["All", "CRITICAL", "HIGH", "MEDIUM", "LOW"])
    status_filter = f3.selectbox("Case status", ["All", "OPEN", "IN_PROGRESS", "ESCALATED", "RESOLVED"])
    case_search = f4.text_input("Search cases", placeholder="Case, shipment, carrier, commodity…")
    filters = {"exception_type": "" if type_filter == "All" else type_filter,
               "severity": "" if sev_filter == "All" else sev_filter,
               "status": "" if status_filter == "All" else status_filter}
    cases = db.list_cases(filters)
    if case_search.strip():
        needle = case_search.strip().casefold()
        cases = [item for item in cases if any(needle in str(item.get(key, "")).casefold()
                 for key in ("case_id", "shipment_id", "carrier_id", "commodity", "description", "origin", "destination"))]
    st.write(f"**{len(cases)}** matching exception(s) · {len(cases_all)} total synthetic cases")
    if not cases:
        st.info("No cases match the selected filters.")
    for case in cases:
        with st.container(border=True):
            c1, c2, c3, c4, c5, c6 = st.columns([1.55, 1.2, 1.05, 1.1, 1.0, 1.25])
            c1.markdown(f"**{case['case_id']}**\n\n{case['shipment_id']}")
            c2.write(case["exception_type"].replace("_", " ").title())
            c3.write(case["severity"])
            c4.write(case["status"].replace("_", " ").title())
            c5.write(fmt_money(case["cargo_value"]))
            if c6.button("▶ Investigate", key=f"run_{case['case_id']}", type="primary", use_container_width=True):
                with st.spinner(f"Running agent workflow for {case['case_id']}..."):
                    try:
                        context = WorkflowController().run(case["case_id"], fault=fault, llm_mode=llm_mode, model=model_name)
                        st.session_state.selected_case = case["case_id"]
                        st.session_state.last_run_id = context["run_id"]
                        st.success(f"Investigation complete: {context['status'].replace('_', ' ').title()}")
                        st.rerun()
                    except Exception as exc:  # visible failure; no synthetic success is claimed
                        st.error(f"Investigation failed: {type(exc).__name__}: {exc}")
            st.caption(case["description"])
    st.markdown("---")
    st.info("Demo suggestion: run **CASE-20260006** with **Omit liability cap** to watch the Critic reject the first proposal and the Resolver correct it on retry.")

# ========================== PAGE 2: CONSOLE ============================
elif page == "Investigation Console":
    st.markdown("<div class='main-header'>Investigation Console</div>", unsafe_allow_html=True)
    st.caption("Inspect the five-agent trace, evidence ledger, policy outcome, Critic validation and retry history.")
    cases = db.list_cases()
    case_ids = [x["case_id"] for x in cases]
    default_index = case_ids.index(st.session_state.selected_case) if st.session_state.selected_case in case_ids else 0
    chosen_case = st.selectbox("Case", case_ids, index=default_index if case_ids else None)
    ctx = load_context_for_case(chosen_case) if chosen_case else None
    if not ctx:
        st.info("No investigation has been run for this case. Open Exception Queue and click Investigate.")
    else:
        render_case_header(ctx)
        render_agent_pipeline(ctx)
        triage_flags = ctx.get("triage", {}).get("risk_flags", [])
        if triage_flags:
            with st.expander("Triage risk flags", expanded=False):
                for flag in triage_flags:
                    st.markdown(f"- {flag}")
        st.caption(f"Investigator source: {ctx.get('investigator_source', 'deterministic')} · Resolver source: {ctx.get('resolver_source', 'deterministic')} · Engine: {ctx.get('engine', 'unknown')}")
        if ctx.get("investigator_note", ""):
            st.caption(ctx.get("investigator_note", ""))
        if ctx.get("resolver_note"):
            st.caption(ctx["resolver_note"])
        t1, t2, t3, t4 = st.tabs(["Resolution", "Evidence", "Critic & retries", "Execution trace"])
        with t1:
            render_resolution(ctx)
            if ctx.get("summary"):
                st.markdown("#### Reviewer summary")
                st.write(ctx["summary"])
                if ctx.get("critic_verdict") == "PASS":
                    st.caption("The structured proposal passed the Critic. This summary is explanatory only and does not execute the recommended action.")
                else:
                    st.warning("This proposal is not Critic-validated. Do not act on it without human review.")
        with t2:
            render_evidence(ctx)
        with t3:
            render_critic(ctx)
        with t4:
            st.caption(f"Workflow engine: {ctx.get('engine', 'unknown')} · run ID: {ctx.get('run_id', '—')}")
            render_trace(ctx)
        st.download_button("Download complete investigation JSON", json.dumps(ctx, indent=2, default=str),
                           file_name=f"{ctx['case_id']}_{ctx['run_id'][:8]}.json", mime="application/json")

# ========================= PAGE 3: APPROVAL ============================
elif page == "Resolution & Approval":
    st.markdown("<div class='main-header'>Resolution & Approval</div>", unsafe_allow_html=True)
    st.caption("Human-in-the-loop control for cases that exceed policy thresholds or lack verified evidence.")
    pending = db.pending_investigations()
    if not pending:
        st.success("No investigations are currently waiting for human approval.")
    else:
        labels = {x["run_id"]: f"{x['result']['case_id']} · {x['result']['case']['exception_type']} · {x['started_at']}" for x in pending}
        run_id = st.selectbox("Pending investigation", [x["run_id"] for x in pending], format_func=lambda v: labels[v])
        chosen = db.get_investigation(run_id)
        if chosen:
            ctx = chosen["result"]
            render_case_header(ctx)
            render_resolution(ctx)
            with st.expander("Evidence snapshot before review", expanded=False):
                render_evidence(ctx)
            reviewer = st.text_input("Reviewer identifier", value="claims_manager")
            note = st.text_area("Reviewer note", placeholder="Record why the recommendation is approved, rejected, overridden, or sent back for evidence.")
            action_values = sorted(ALLOWED_ACTIONS.get(ctx["case"]["exception_type"], set()))
            override_action = st.selectbox("Override action (optional)", action_values, help="An override is recorded in the audit trail. Changing the action resets the proposed amount to $0 pending a separate verified assessment.")
            b1, b2, b3, b4 = st.columns(4)
            can_approve = bool(ctx.get("resolution")) and ctx.get("critic_verdict") == "PASS"
            if b1.button("✅ Approve recommendation", type="primary", disabled=not can_approve, use_container_width=True):
                try:
                    db.apply_human_decision(run_id, "APPROVE", reviewer.strip() or "claims_manager", note)
                    st.success("Decision recorded and case status updated.")
                    st.rerun()
                except Exception as exc:
                    st.error(str(exc))
            if b2.button("↪ Override action", use_container_width=True):
                try:
                    db.apply_human_decision(run_id, "OVERRIDE", reviewer.strip() or "claims_manager", note, override_action=override_action)
                    st.success("Override recorded in the audit trail.")
                    st.rerun()
                except Exception as exc:
                    st.error(str(exc))
            if b3.button("⛔ Reject", use_container_width=True):
                try:
                    db.apply_human_decision(run_id, "REJECT", reviewer.strip() or "claims_manager", note)
                    st.success("Rejection recorded.")
                    st.rerun()
                except Exception as exc:
                    st.error(str(exc))
            if b4.button("📄 Request evidence", use_container_width=True):
                try:
                    db.apply_human_decision(run_id, "REQUEST_EVIDENCE", reviewer.strip() or "claims_manager", note)
                    st.success("Case returned to the open queue for further evidence.")
                    st.rerun()
                except Exception as exc:
                    st.error(str(exc))
            if not can_approve:
                st.warning("Approval is disabled because no validated recommendation exists or the Critic did not pass. Request evidence or record an explicitly reasoned override instead.")

# ========================== PAGE 4: DASHBOARD ===========================
elif page == "Operations Dashboard":
    st.markdown("<div class='main-header'>Operations Dashboard</div>", unsafe_allow_html=True)
    st.caption("Operational counts and outcomes derived from persisted synthetic cases and workflow runs.")
    summary = db.dashboard_summary()
    k1, k2, k3, k4 = st.columns(4)
    k1.metric("Shipments", summary["shipments"])
    k2.metric("Exceptions", summary["exceptions"])
    k3.metric("Open", summary["open"])
    k4.metric("Escalated", summary["escalated"])
    k5, k6, k7, k8 = st.columns(4)
    k5.metric("Resolved", summary["resolved"])
    k6.metric("In progress", summary["in_progress"])
    k7.metric("Investigation runs", summary["investigations"])
    all_runs = db.list_investigations()
    critic_fails = sum(1 for r in all_runs if r["result"].get("rejected_attempts"))
    k8.metric("Runs with Critic revision", critic_fails)

    cases = db.list_cases()
    col1, col2 = st.columns(2)
    with col1:
        counts = pd.DataFrame(cases).groupby("exception_type", as_index=False).size().rename(columns={"size": "Cases"}) if cases else pd.DataFrame(columns=["exception_type", "Cases"])
        if not counts.empty:
            fig = px.pie(counts, names="exception_type", values="Cases", hole=0.48, title="Exception mix")
            st.plotly_chart(fig, use_container_width=True)
        else:
            st.info("No case data available.")
    with col2:
        sev = pd.DataFrame(cases).groupby("severity", as_index=False).size().rename(columns={"size": "Cases"}) if cases else pd.DataFrame(columns=["severity", "Cases"])
        if not sev.empty:
            order = ["LOW", "MEDIUM", "HIGH", "CRITICAL"]
            sev["severity"] = pd.Categorical(sev["severity"], categories=order, ordered=True)
            sev = sev.sort_values("severity")
            fig = px.bar(sev, x="severity", y="Cases", title="Cases by severity", text="Cases")
            st.plotly_chart(fig, use_container_width=True)
        else:
            st.info("No severity data available.")
    st.markdown("#### Five-agent activity")
    events = db.get_audit_events()
    agent_events = [event for event in events if event.get("agent") in AGENT_NAMES]
    if agent_events:
        activity = pd.DataFrame(agent_events)
        per_agent = activity.groupby(["agent", "status"], as_index=False).size().rename(columns={"size": "Events"})
        fig_agent = px.bar(per_agent, x="agent", y="Events", color="status", barmode="stack", title="Recorded events by agent")
        fig_agent.update_layout(xaxis_title="", yaxis_title="Audit events", legend_title="Outcome")
        st.plotly_chart(fig_agent, use_container_width=True)
    else:
        st.caption("Run an investigation to populate five-agent activity metrics.")
    st.markdown("#### Latest investigations")
    if all_runs:
        rows = []
        for item in all_runs[:20]:
            result = item["result"]
            resolution = result.get("resolution") or {}
            rows.append({"Started": item["started_at"], "Case": item["case_id"], "Type": result["case"]["exception_type"],
                         "Status": item["status"], "Action": resolution.get("action", "—"), "Amount": fmt_money(resolution.get("amount", 0)),
                         "Critic": result.get("critic_verdict", "PENDING"), "Attempts": result.get("attempt", 0)})
        st.dataframe(pd.DataFrame(rows), use_container_width=True, hide_index=True)
    else:
        st.info("Run one or more investigations to populate workflow metrics.")
    st.caption("Metrics are calculated from the local demo database. They are not real freight-operation KPIs and resolution times are not simulated as real-world performance.")

# ============================ PAGE 5: AUDIT =============================
elif page == "Audit & Compliance":
    st.markdown("<div class='main-header'>Audit & Compliance</div>", unsafe_allow_html=True)
    st.caption("Review the execution trail and verify the SHA-256 hash chain for a case.")
    cases = db.list_cases()
    ids = ["All cases"] + [x["case_id"] for x in cases]
    selected = st.selectbox("Filter by case", ids)
    selected_id = None if selected == "All cases" else selected
    events = db.get_audit_events(case_id=selected_id)
    if not events:
        st.info("No audit events yet. Run an investigation from the Exception Queue.")
    else:
        st.write(f"**{len(events)} audit event(s)**")
        if selected_id:
            ok, message = db.verify_audit_chain(selected_id)
            (st.success if ok else st.error)(message)
        else:
            chain_results = [db.verify_audit_chain(case_id) for case_id in [x["case_id"] for x in cases]]
            passed = sum(1 for ok, _ in chain_results if ok)
            failed = sum(1 for ok, _ in chain_results if not ok)
            st.info(f"Chain verification: {passed} case(s) with valid/empty chains; {failed} case(s) with detected integrity issues.")
        table = pd.DataFrame([{"ID": e["id"], "Timestamp (UTC)": e["timestamp"], "Case": e["case_id"], "Run": e["run_id"],
                               "Agent": e["agent"], "Event": e["event_type"], "Status": e["status"], "Details": json.dumps(e["details"], ensure_ascii=False),
                               "Previous hash": e["prev_hash"], "Event hash": e["event_hash"]} for e in events])
        st.dataframe(table, use_container_width=True, hide_index=True)
        st.download_button("Export audit events (JSON)", json.dumps(events, indent=2, default=str), "fair_audit_events.json", mime="application/json")
        st.download_button("Export audit events (CSV)", table.to_csv(index=False), "fair_audit_events.csv", mime="text/csv")
        st.caption("The chain is tamper-evident, not an immutable external ledger. An administrator with direct database access could alter data and recompute hashes; use external signed storage for production.")

st.markdown("---")
st.caption("F.A.I.R. 2.1 · Five-agent academic proof of concept · Synthetic data only · No live carrier integrations, payments, claims submissions, or customer notifications")
