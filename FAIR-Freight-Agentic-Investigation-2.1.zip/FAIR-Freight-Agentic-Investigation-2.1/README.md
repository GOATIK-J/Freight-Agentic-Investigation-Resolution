# F.A.I.R. 2.1 — Freight Agentic Investigation & Resolution

**Five agents. One auditable workflow. Human oversight when evidence or policy requires it.**

F.A.I.R. is an academic proof of concept that investigates synthetic freight exceptions. It combines an explicit five-agent workflow, deterministic policy calculations, an independently validating Critic, bounded correction, a five-page Streamlit operations interface, SQLite persistence and a tamper-evident audit trail.

> **Important:** All data and evidence are synthetic. This demo does not connect to live carrier systems, submit claims, transmit documents, make payments or notify customers. It is not production software or legal advice.

## Exactly five agents

1. **Triage Agent** — classifies the supported exception family, assigns priority and surfaces risk flags.
2. **Investigator Agent** — creates an exception-specific evidence plan from a fixed allow-list.
3. **Evidence Collector Agent** — retrieves source-tagged synthetic evidence, retries failed reads, and records gaps.
4. **Resolver Agent** — proposes a policy-constrained action and amount; it never performs an external action.
5. **Critic Agent** — independently recomputes the expected action/amount and validates policy references, action allow-list and financial cap.

The LangGraph contains exactly five agent nodes. Conditional edges and the bounded Resolver–Critic retry are orchestration, not additional agents. Human approval and final status routing happen in the controller after the graph stops; there is no separate Router, Finalizer, Approval or Narrative agent.

```mermaid
flowchart TD
  A([Start]) --> T[Triage Agent]
  T --> I[Investigator Agent]
  I --> E[Evidence Collector Agent]
  E -->|Critical evidence gap| H[Controller routes to human review]
  E -->|Can proceed| R[Resolver Agent]
  R --> C[Critic Agent]
  C -->|FAIL; one retry available| R
  C -->|PASS; low risk| F([Validated recommendation])
  C -->|Review trigger or retries exhausted| H
```

## Highlights

- **Five-page interface:** Exception Queue, Investigation Console, Resolution & Approval, Operations Dashboard, Audit & Compliance.
- **Five exception families:** damage, delay, customs hold, misroute and refused delivery, represented by ten synthetic cases.
- **Exception-specific evidence plans:** the model cannot introduce or remove tools from the allow-list.
- **Evidence provenance:** source, finding, retrieval timestamp, retry count, criticality and gaps are recorded for each evidence item.
- **Critic and bounded correction:** an independent policy path validates the Resolver's output; a failed proposal can be revised once, then the system escalates.
- **Deterministic safeguards:** policy code controls financial calculations, caps and allowed actions. LLM output is only a candidate.
- **Human-in-the-loop controls:** approve a Critic-passed recommendation, reject it, request evidence or record a constrained override, with reviewer note and timestamp.
- **Persistence:** SQLite stores cases, shipment data, runs, decisions and audit events across restarts.
- **Audit integrity checks:** SHA-256 hashes link events in a per-case chain, with JSON/CSV export and verification.
- **Optional local Ollama:** only the Investigator (tool order) and Resolver (candidate proposal) call the local model. Offline deterministic mode is the default and fallback.
- **Automated tests and evaluation:** run tests with `pytest`; run the synthetic-case evaluation script to export outcomes to CSV.

## Quick start — Windows CMD

1. Extract the ZIP.
2. Open CMD in the extracted `FAIR-Freight-Agentic-Investigation-2.1` folder. Run `dir` and check that `app.py` and `requirements.txt` appear.
3. Create and activate a virtual environment:

   ```cmd
   py -3 -m venv .venv
   .venv\Scripts\activate.bat
   ```

4. Install dependencies:

   ```cmd
   python -m pip install --upgrade pip
   pip install -r requirements.txt
   ```

5. Start the app:

   ```cmd
   streamlit run app.py
   ```

6. Open **http://localhost:8501** if a browser tab does not open automatically.

**One-click option:** double-click `run_windows.bat`. It creates `.venv` if necessary, installs dependencies and starts Streamlit.

### PowerShell

```powershell
py -3 -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
pip install -r requirements.txt
streamlit run app.py
```

If PowerShell blocks activation, use CMD instead of changing the machine-wide execution policy.

## Baseline synthetic evaluation

The included ten-case fixture set was run through the built-in workflow during validation: **10 cases evaluated, 9 Critic passes and 1 case safely stopped before resolution because critical evidence was missing; 5 cases routed to human review**. These are results from the supplied synthetic examples only, not estimates of real-world freight performance. Re-run the evaluation script after changing policies or fixtures.

## Recommended demo

### A. Normal damage claim

Run `CASE-20260001` with **None** for demo fault injection. Expected damage adjustment:

`$4,200.00 - $300.00 + $180.00 - $250.00 = $3,830.00`

### B. Critic catches a Resolver mistake

Choose **Omit liability cap** and run `CASE-20260006`. The first proposal is intentionally incorrect for demonstration. Critic should reject it, Resolver should revise it once, and the corrected amount should be `$50,000.00`. Because this is a high-value strategic case, it still routes for human approval.

### C. Critical evidence missing

Run `CASE-20260009`. The damage report is unavailable, so the system blocks automated resolution and sends the case for human review. Resolver and Critic are marked “Skipped safely”.

### D. Weather verification gap

Run `CASE-20260002`. Weather evidence is unavailable. F.A.I.R. must not deny the delay case on unverified weather; it records a review reason.

### E. Review and audit

Open **Resolution & Approval**, record a reviewer identity and note, and approve/reject/request evidence or make an explicit permitted override. Open **Audit & Compliance** to verify the hash chain and export audit data.

See [`docs/demo_script.md`](docs/demo_script.md) for presentation wording and expected outcomes.

## Optional local Ollama

F.A.I.R. works without Ollama. To use a local model, install Ollama, start the local service, and pull a model such as:

```cmd
ollama pull llama3.2
```

Choose **Ollama local LLM** in the sidebar. The Investigator may only reorder the fixed allow-listed tool plan; the Resolver may submit a structured proposal. The Critic independently checks the action, amount, cap and policy references. Invalid responses fall back safely or are rejected by the Critic. The LLM is not treated as evidence and cannot trigger external actions.

## Tests and evaluation

```cmd
python -m pytest -q
```

To run every synthetic case and save a results table:

```cmd
python scripts/evaluate_cases.py --output evaluation_results.csv
```

The evaluation uses the local seeded SQLite database and creates investigation/audit records. The CSV includes case type, triage priority, result status, action, amount, Critic verdict, attempts and evidence gaps.

## Project structure

```text
FAIR-Freight-Agentic-Investigation-2.1/
├── app.py
├── requirements.txt
├── run_windows.bat
├── .streamlit/config.toml
├── fair/
│   ├── agents/
│   │   ├── triage.py
│   │   ├── investigator.py
│   │   ├── evidence_collector.py
│   │   ├── resolver.py
│   │   └── critic.py
│   ├── database.py
│   ├── seed.py
│   ├── evidence.py
│   ├── policy.py
│   ├── llm.py
│   └── workflow.py
├── tests/test_core.py
├── scripts/evaluate_cases.py
├── docs/architecture.md
├── docs/demo_script.md
└── data/.gitkeep
```

## Controls and limitations

- Triage priority is a deterministic heuristic for this prototype, not a trained classifier.
- The case record supplies the authoritative exception family; Triage cross-checks it with lightweight explainable keyword signals, not a trained classifier, and sends contradictory or ambiguous signals for human review. This is not a production text classifier.
- Evidence documents are structured fixtures, not real PDFs or images. Live TMS, carrier, weather and customs integrations are not configured.
- Resolver actions are recommendations only. No real financial or operational action is executed.
- Confidence is a heuristic based on evidence availability and must not be interpreted as a calibrated probability.
- Reviewer identity is a plain text input, not authenticated access control.
- The audit hash chain detects casual or partial modification but is not an immutable external ledger; an administrator with database write access could alter records and recompute hashes.
- Production use would need authentication/authorization, secret management, production databases, external signed logging, monitoring, backups, domain validation and legal/compliance review.

## Troubleshooting

- **`py` not recognized:** install Python 3.11+ and enable PATH; try `python --version`.
- **`streamlit` not recognized:** activate `.venv` then rerun `pip install -r requirements.txt`.
- **`requirements.txt` not found:** open CMD in the extracted project folder, not inside the ZIP preview.
- **Ollama connection error:** choose **Offline deterministic**; the application is designed to work without an LLM.
- **Port 8501 occupied:** run `streamlit run app.py --server.port 8502` and open `http://localhost:8502`.

Academic proof of concept — synthetic data only — no live carrier integrations.
