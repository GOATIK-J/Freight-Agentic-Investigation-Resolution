"""F.A.I.R. Freight Agentic Investigation & Resolution package."""
__version__ = "2.1.0"
