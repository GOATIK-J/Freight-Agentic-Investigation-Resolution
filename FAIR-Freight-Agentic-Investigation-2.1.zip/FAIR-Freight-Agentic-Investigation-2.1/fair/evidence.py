"""Read-only synthetic evidence tools used by the Evidence Collector Agent."""
from __future__ import annotations

from datetime import datetime, timezone
from typing import Any


class EvidenceError(RuntimeError):
    """Evidence was missing, unavailable, or could not be parsed."""


TOOL_PURPOSE: dict[str, str] = {
    "get_tracking": "Verify shipment milestones, delivery status and reported exceptions",
    "get_pod": "Inspect proof-of-delivery availability and delivery exception notation",
    "get_damage_report": "Validate documented damage and estimate loss adjustments",
    "get_carrier_history": "Check carrier-level context for similar events",
    "get_weather": "Check independently verified weather severity during transit",
    "get_service_level": "Read applicable delivery-service credit terms",
    "get_customs_documents": "Check required customs document completeness",
    "get_customs_status": "Verify customs hold and duty settlement status",
    "get_route_check": "Compare the expected and recorded transportation route",
    "get_delivery_attempts": "Inspect delivery attempts and recorded refusal reason",
    "get_contract_terms": "Retrieve the synthetic contractual cap and authority rules",
}

TOOLS_BY_EXCEPTION: dict[str, list[str]] = {
    "DAMAGE": ["get_tracking", "get_pod", "get_damage_report", "get_carrier_history", "get_contract_terms"],
    "DELAY": ["get_tracking", "get_weather", "get_service_level", "get_contract_terms"],
    "CUSTOMS_HOLD": ["get_customs_documents", "get_customs_status", "get_contract_terms"],
    "MISROUTE": ["get_tracking", "get_route_check", "get_contract_terms"],
    "REFUSED_DELIVERY": ["get_tracking", "get_delivery_attempts", "get_pod", "get_contract_terms"],
}

CRITICAL_TOOLS: dict[str, set[str]] = {
    "DAMAGE": {"get_tracking", "get_pod", "get_damage_report"},
    "DELAY": {"get_tracking", "get_service_level"},
    "CUSTOMS_HOLD": {"get_customs_documents", "get_customs_status"},
    "MISROUTE": {"get_tracking", "get_route_check"},
    "REFUSED_DELIVERY": {"get_tracking", "get_delivery_attempts", "get_pod"},
}

TOOL_KEYS: dict[str, str] = {
    "get_tracking": "tracking", "get_pod": "pod", "get_damage_report": "damage_report",
    "get_carrier_history": "carrier_history", "get_weather": "weather", "get_service_level": "service_level",
    "get_customs_documents": "customs_documents", "get_customs_status": "customs_status",
    "get_route_check": "route_check", "get_delivery_attempts": "delivery_attempts", "get_contract_terms": "contract_terms",
}


def build_plan(exception_type: str) -> list[dict[str, Any]]:
    if exception_type not in TOOLS_BY_EXCEPTION:
        raise ValueError(f"Unsupported exception type: {exception_type}")
    critical = CRITICAL_TOOLS[exception_type]
    return [{"tool": name, "purpose": TOOL_PURPOSE[name], "critical": name in critical} for name in TOOLS_BY_EXCEPTION[exception_type]]


def run_tool(tool_name: str, shipment: dict[str, Any]) -> dict[str, Any]:
    if tool_name not in TOOL_KEYS:
        raise EvidenceError(f"Tool {tool_name!r} is not allow-listed.")
    key = TOOL_KEYS[tool_name]
    value = shipment.get("evidence", {}).get(key)
    if value is None:
        raise EvidenceError(f"{tool_name}: source unavailable or required record missing.")
    if not isinstance(value, dict):
        raise EvidenceError(f"{tool_name}: malformed evidence payload.")
    if value.get("available") is False:
        raise EvidenceError(f"{tool_name}: provider marked the source unavailable.")
    return {"source": f"Synthetic:{key}", "data": value}


def collect_evidence(plan: list[dict[str, Any]], shipment: dict[str, Any], retries: int = 2) -> list[dict[str, Any]]:
    results: list[dict[str, Any]] = []
    for step in plan:
        last_error = ""
        retrieved: dict[str, Any] | None = None
        attempt_count = 0
        for attempt in range(1, retries + 1):
            attempt_count = attempt
            try:
                retrieved = run_tool(step["tool"], shipment)
                break
            except EvidenceError as exc:
                last_error = str(exc)
        timestamp = datetime.now(timezone.utc).replace(microsecond=0).isoformat()
        if retrieved is not None:
            data = retrieved["data"]
            finding = summarize_finding(step["tool"], data)
            results.append({
                "tool_name": step["tool"], "purpose": step["purpose"], "status": "RETRIEVED",
                "source": retrieved["source"], "finding": finding, "details": data,
                "critical": bool(step["critical"]), "attempts": attempt_count, "retrieved_at": timestamp,
            })
        else:
            results.append({
                "tool_name": step["tool"], "purpose": step["purpose"], "status": "UNAVAILABLE",
                "source": f"Synthetic:{TOOL_KEYS.get(step['tool'], 'unknown')}", "finding": last_error,
                "details": {"error": last_error}, "critical": bool(step["critical"]),
                "attempts": attempt_count, "retrieved_at": timestamp,
            })
    return results


def summarize_finding(tool: str, data: dict[str, Any]) -> str:
    if tool == "get_tracking":
        return f"Status: {data.get('status', 'unknown')}; {len(data.get('milestones', []))} milestone(s) found."
    if tool == "get_pod":
        return "Proof of delivery present; damage notation found." if data.get("present") and data.get("damage_notation") else "Proof of delivery or damage notation is incomplete."
    if tool == "get_damage_report":
        return f"Damage {'confirmed' if data.get('confirmed') else 'not confirmed'}; reported loss ${float(data.get('estimated_loss', 0)):,.2f}."
    if tool == "get_carrier_history":
        return f"Recent damage rate {data.get('recent_damage_rate', 'not supplied')}; related claims {data.get('prior_related_claims', 'unknown')}."
    if tool == "get_weather":
        return f"Weather verification {'confirmed' if data.get('verified') else 'not confirmed'}; maximum severity {data.get('max_severity', 'unknown')}."
    if tool == "get_service_level":
        return f"Service level allows ${float(data.get('credit_per_day', 0)):,.2f}/late day, up to ${float(data.get('maximum_credit', 0)):,.2f}."
    if tool == "get_customs_documents":
        missing = data.get("missing_documents", [])
        return f"{len(missing)} required document(s) missing." if missing else "Required customs documents appear complete."
    if tool == "get_customs_status":
        return f"Customs status: {data.get('status', 'unknown')}; duties paid: {data.get('duties_paid', 'unknown')}."
    if tool == "get_route_check":
        return "Route deviation detected." if data.get("deviation") else "Recorded route matches the expected route."
    if tool == "get_delivery_attempts":
        return f"{data.get('attempts', 0)} delivery attempt(s); reason: {data.get('refusal_reason', 'not recorded')}."
    if tool == "get_contract_terms":
        return f"Contract cap ${float(data.get('liability_cap', 0)):,.2f}; authority limit ${float(data.get('authority_limit', 0)):,.2f}."
    return "Evidence retrieved."
