"""Optional local Ollama support used only by the Investigator and Resolver agents.

Ollama is called only on localhost. Any suggestion is structured, schema-checked and
validated by the Critic; deterministic policy rules remain the decision authority.
"""
from __future__ import annotations

import json
from typing import Any

import requests

OLLAMA_URL = "http://localhost:11434/api/generate"


def _generate(prompt: str, model: str, timeout: float = 8.0) -> str:
    response = requests.post(
        OLLAMA_URL,
        json={"model": model, "prompt": prompt, "stream": False, "format": "json",
              "options": {"temperature": 0.0}},
        timeout=timeout,
    )
    response.raise_for_status()
    text = str(response.json().get("response", "")).strip()
    if not text:
        raise ValueError("Ollama returned an empty response.")
    return text


def propose_tool_order(case: dict[str, Any], shipment: dict[str, Any], plan: list[dict[str, Any]], model: str = "llama3.2") -> tuple[list[str] | None, str]:
    """Let the Investigator prioritize a fixed, pre-approved tool set; tools cannot be added or omitted."""
    tools = [item["tool"] for item in plan]
    prompt = (
        "You are a planning agent for a freight exception investigation. Return JSON only: "
        '{"tool_order": ["tool_name", ...]}. Rank the supplied tools in the most useful investigation order. '
        "You MUST include each supplied tool exactly once and MUST NOT create tools or omit tools. Do not return commentary.\n"
        + json.dumps({"exception_type": case.get("exception_type"), "description": case.get("description"),
                      "shipment": {k: shipment.get(k) for k in ("origin", "destination", "commodity", "cargo_value")},
                      "allowed_tool_purposes": plan}, ensure_ascii=False)
    )
    try:
        parsed = json.loads(_generate(prompt, model, timeout=7.0))
        order = parsed.get("tool_order") if isinstance(parsed, dict) else None
        if (not isinstance(order, list) or len(order) != len(tools) or any(not isinstance(x, str) for x in order)
                or len(set(order)) != len(order) or set(order) != set(tools)):
            return None, "Investigator output did not match the allow-listed tool schema; deterministic plan retained."
        return order, ""
    except Exception as exc:  # noqa: BLE001 - optional local model never blocks the workflow
        return None, f"Ollama Investigator unavailable or invalid: {type(exc).__name__}: {exc}"


def propose_resolution(
    case: dict[str, Any],
    shipment: dict[str, Any],
    bundle: list[dict[str, Any]],
    allowed_actions: set[str],
    model: str = "llama3.2",
    critic_feedback: list[str] | None = None,
) -> tuple[dict[str, Any] | None, str]:
    """Request a structured Resolver proposal; the separate Critic recomputes action and amount."""
    compact_evidence = [
        {"tool": x.get("tool_name"), "status": x.get("status"), "finding": x.get("finding"), "details": x.get("details", {})}
        for x in bundle
    ]
    prompt = (
        "You are the Resolver agent for a synthetic freight-exception demonstration. Return valid JSON only with keys: "
        '"action" (string), "amount" (number), "root_cause" (string), "rationale" (string), "policy_references" (array of strings). '
        "Choose action ONLY from the allowed_actions list. Never invent evidence or policy references. Money must be non-negative. "
        "For DAMAGE, adjusted estimate = min(estimated_loss, cargo_value) - salvage_value + freight_refund - deductible; "
        "floor at zero and apply the lowest of the contract liability cap, customer-tier ceiling and cargo value. "
        "For DELAY, compute late days from promised and actual delivery and apply the evidence's service-level credit per day and maximum. "
        "For CUSTOMS_HOLD, prioritize missing documents or duty status. For MISROUTE, use the route check. "
        "For REFUSED_DELIVERY, use the recorded refusal reason. Do not deny a claim due to unverified weather. "
        "A later independent Critic will verify this proposal, so be precise.\n"
        + json.dumps({
            "case": {k: case.get(k) for k in ("case_id", "exception_type", "severity", "description")},
            "shipment": {k: shipment.get(k) for k in ("shipment_id", "cargo_value", "customer_tier", "promised_delivery", "actual_delivery", "origin", "destination")},
            "allowed_actions": sorted(allowed_actions), "evidence": compact_evidence,
            "critic_feedback_from_prior_attempt": critic_feedback or [],
        }, ensure_ascii=False)
    )
    try:
        parsed = json.loads(_generate(prompt, model, timeout=10.0))
        if not isinstance(parsed, dict):
            raise ValueError("Resolver response was not a JSON object.")
        action = parsed.get("action")
        amount = parsed.get("amount")
        rationale = parsed.get("rationale")
        refs = parsed.get("policy_references")
        if action not in allowed_actions:
            raise ValueError(f"Action {action!r} is not allow-listed.")
        if isinstance(amount, bool) or not isinstance(amount, (int, float)) or amount < 0:
            raise ValueError("Amount must be a non-negative number.")
        if not isinstance(parsed.get("root_cause"), str) or not parsed["root_cause"].strip():
            raise ValueError("Root cause is missing.")
        if not isinstance(rationale, str) or not rationale.strip():
            raise ValueError("Rationale is missing.")
        if not isinstance(refs, list) or any(not isinstance(x, str) for x in refs):
            raise ValueError("Policy references must be a list of strings.")
        return {"action": action, "amount": round(float(amount), 2), "root_cause": parsed["root_cause"].strip(),
                "rationale": rationale.strip(), "policy_references": refs}, ""
    except Exception as exc:  # noqa: BLE001 - bad output becomes a deterministic proposal, never a crash
        return None, f"Ollama Resolver unavailable or invalid: {type(exc).__name__}: {exc}"
