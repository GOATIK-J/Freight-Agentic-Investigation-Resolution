"""Synthetic freight shipments and exception cases for the academic demo."""
from __future__ import annotations

from datetime import datetime
from typing import Any


def _ev(**kwargs: Any) -> dict[str, Any]:
    return kwargs

SHIPMENTS: list[dict[str, Any]] = [
    {
        "shipment_id": "SHP-1001", "carrier_id": "APEX-CHI", "origin": "Chicago, IL", "destination": "Columbus, OH",
        "commodity": "Consumer electronics accessories", "cargo_value": 4500.0, "customer_tier": "Standard",
        "ship_date": "2026-10-01", "promised_delivery": "2026-10-03", "actual_delivery": "2026-10-03",
        "evidence": {
            "tracking": _ev(status="DELIVERED", milestones=["Picked up in Chicago", "Delivered in Columbus"], exception="Damage noted at dock"),
            "pod": _ev(present=True, damage_notation=True, signed_by="J. Miller"),
            "damage_report": _ev(confirmed=True, estimated_loss=4200.0, salvage_value=300.0, freight_refund=180.0, deductible=250.0, report_id="DR-1001"),
            "carrier_history": _ev(recent_damage_rate="1.8%", prior_related_claims=0),
            "contract_terms": _ev(liability_cap=50000.0, filing_days=270, severe_weather_level=4, authority_limit=10000.0),
        },
    },
    {
        "shipment_id": "SHP-1002", "carrier_id": "NORTHSTAR-7", "origin": "Houston, TX", "destination": "Denver, CO",
        "commodity": "Industrial components", "cargo_value": 14000.0, "customer_tier": "Standard",
        "ship_date": "2026-10-02", "promised_delivery": "2026-10-05", "actual_delivery": "2026-10-09",
        "evidence": {
            "tracking": _ev(status="DELIVERED_LATE", promised_delivery="2026-10-05", actual_delivery="2026-10-09", milestones=["Pickup", "Weather delay near Amarillo", "Delivered four days late"]),
            "weather": None,
            "service_level": _ev(credit_per_day=250.0, maximum_credit=1200.0, terms_id="SLA-STD-01"),
            "contract_terms": _ev(liability_cap=50000.0, filing_days=270, severe_weather_level=4, authority_limit=10000.0),
        },
    },
    {
        "shipment_id": "SHP-1003", "carrier_id": "GLOBAL-TRANSIT", "origin": "Los Angeles, CA", "destination": "Chicago, IL",
        "commodity": "Laboratory equipment", "cargo_value": 28000.0, "customer_tier": "Premium",
        "ship_date": "2026-10-05", "promised_delivery": "2026-10-10", "actual_delivery": None,
        "evidence": {
            "customs_documents": _ev(available=True, documents_on_file=["Packing list"], missing_documents=["Commercial invoice", "Certificate of origin"]),
            "customs_status": _ev(status="HOLD", duties_paid=False, hold_reason="Supporting documents required"),
            "contract_terms": _ev(liability_cap=50000.0, filing_days=270, severe_weather_level=4, authority_limit=10000.0),
        },
    },
    {
        "shipment_id": "SHP-1004", "carrier_id": "APEX-SOUTH", "origin": "Dallas, TX", "destination": "Atlanta, GA",
        "commodity": "Retail apparel", "cargo_value": 12000.0, "customer_tier": "Standard",
        "ship_date": "2026-10-06", "promised_delivery": "2026-10-09", "actual_delivery": "2026-10-09",
        "evidence": {
            "tracking": _ev(status="DELIVERED", milestones=["Pickup in Dallas", "Unexpected scan in Little Rock", "Delivered in Atlanta" ]),
            "route_check": _ev(deviation=True, expected_route="Dallas → Birmingham → Atlanta", actual_route="Dallas → Little Rock → Atlanta", extra_miles=180),
            "contract_terms": _ev(liability_cap=50000.0, filing_days=270, severe_weather_level=4, authority_limit=10000.0),
        },
    },
    {
        "shipment_id": "SHP-1005", "carrier_id": "EASTLINE-2", "origin": "Newark, NJ", "destination": "Boston, MA",
        "commodity": "Office furniture", "cargo_value": 8000.0, "customer_tier": "Standard",
        "ship_date": "2026-10-08", "promised_delivery": "2026-10-10", "actual_delivery": None,
        "evidence": {
            "tracking": _ev(status="DELIVERY_ATTEMPTED", milestones=["Out for delivery", "Recipient unavailable" ]),
            "delivery_attempts": _ev(attempts=1, refusal_reason="consignee_unavailable", next_attempt_available=True),
            "pod": _ev(present=True, damage_notation=False, signed_by=None),
            "contract_terms": _ev(liability_cap=50000.0, filing_days=270, severe_weather_level=4, authority_limit=10000.0),
        },
    },
    {
        "shipment_id": "SHP-1006", "carrier_id": "PACIFIC-PRIME", "origin": "Seattle, WA", "destination": "Miami, FL",
        "commodity": "Precision CNC spindle assemblies", "cargo_value": 128000.0, "customer_tier": "Strategic",
        "ship_date": "2026-10-01", "promised_delivery": "2026-10-07", "actual_delivery": "2026-10-07",
        "evidence": {
            "tracking": _ev(status="DELIVERED_EXCEPTION", milestones=["Picked up in Seattle", "Cross-dock transfer", "Delivered with damage notation"]),
            "pod": _ev(present=True, damage_notation=True, signed_by="M. Alvarez"),
            "damage_report": _ev(confirmed=True, estimated_loss=82000.0, salvage_value=1000.0, freight_refund=1500.0, deductible=250.0, report_id="DR-1006"),
            "carrier_history": _ev(recent_damage_rate="3.2%", prior_related_claims=2),
            "contract_terms": _ev(liability_cap=50000.0, filing_days=270, severe_weather_level=4, authority_limit=10000.0),
        },
    },
    {
        "shipment_id": "SHP-1007", "carrier_id": "NORTHSTAR-7", "origin": "Memphis, TN", "destination": "Nashville, TN",
        "commodity": "Medical supplies", "cargo_value": 22000.0, "customer_tier": "Premium",
        "ship_date": "2026-10-09", "promised_delivery": "2026-10-10", "actual_delivery": "2026-10-12",
        "evidence": {
            "tracking": _ev(status="DELIVERED_LATE", promised_delivery="2026-10-10", actual_delivery="2026-10-12", milestones=["Pickup", "Severe storm warning", "Delivered two days late"]),
            "weather": _ev(verified=True, max_severity=4, events=["Verified severe storm during transit"]),
            "service_level": _ev(credit_per_day=300.0, maximum_credit=1000.0, terms_id="SLA-PRM-02"),
            "contract_terms": _ev(liability_cap=50000.0, filing_days=270, severe_weather_level=4, authority_limit=10000.0),
        },
    },
    {
        "shipment_id": "SHP-1008", "carrier_id": "GLOBAL-TRANSIT", "origin": "Miami, FL", "destination": "Tampa, FL",
        "commodity": "Consumer electronics", "cargo_value": 36000.0, "customer_tier": "Premium",
        "ship_date": "2026-10-10", "promised_delivery": "2026-10-12", "actual_delivery": None,
        "evidence": {
            "customs_documents": _ev(available=True, documents_on_file=["Commercial invoice", "Packing list", "Certificate of origin"], missing_documents=[]),
            "customs_status": _ev(status="DUTY_PENDING", duties_paid=False, hold_reason="Duty settlement confirmation pending"),
            "contract_terms": _ev(liability_cap=50000.0, filing_days=270, severe_weather_level=4, authority_limit=10000.0),
        },
    },
    {
        "shipment_id": "SHP-1009", "carrier_id": "APEX-CHI", "origin": "Cleveland, OH", "destination": "Pittsburgh, PA",
        "commodity": "Machine parts", "cargo_value": 19000.0, "customer_tier": "Standard",
        "ship_date": "2026-10-11", "promised_delivery": "2026-10-13", "actual_delivery": "2026-10-13",
        "evidence": {
            "tracking": _ev(status="DELIVERED_EXCEPTION", milestones=["Delivered", "Damage reported by receiver"]),
            "pod": _ev(present=True, damage_notation=True, signed_by="A. Singh"),
            "damage_report": None,
            "carrier_history": _ev(recent_damage_rate="1.8%", prior_related_claims=0),
            "contract_terms": _ev(liability_cap=50000.0, filing_days=270, severe_weather_level=4, authority_limit=10000.0),
        },
    },
    {
        "shipment_id": "SHP-1010", "carrier_id": "EASTLINE-2", "origin": "Phoenix, AZ", "destination": "Salt Lake City, UT",
        "commodity": "Packaged food products", "cargo_value": 6200.0, "customer_tier": "Standard",
        "ship_date": "2026-10-12", "promised_delivery": "2026-10-15", "actual_delivery": "2026-10-15",
        "evidence": {
            "tracking": _ev(status="DELIVERED", milestones=["Pickup", "Route scans align with plan", "Delivered on time"]),
            "route_check": _ev(deviation=False, expected_route="Phoenix → Las Vegas → Salt Lake City", actual_route="Phoenix → Las Vegas → Salt Lake City", extra_miles=0),
            "contract_terms": _ev(liability_cap=50000.0, filing_days=270, severe_weather_level=4, authority_limit=10000.0),
        },
    },
]

CASES: list[dict[str, Any]] = [
    {"case_id": "CASE-20260001", "shipment_id": "SHP-1001", "exception_type": "DAMAGE", "severity": "HIGH", "status": "OPEN", "reported_at": "2026-10-04T09:10:00", "description": "Two cartons were crushed during unloading; delivery exception is noted on the proof of delivery."},
    {"case_id": "CASE-20260002", "shipment_id": "SHP-1002", "exception_type": "DELAY", "severity": "HIGH", "status": "OPEN", "reported_at": "2026-10-10T10:15:00", "description": "Shipment arrived four days after the promised delivery date; carrier mentioned weather-related disruption."},
    {"case_id": "CASE-20260003", "shipment_id": "SHP-1003", "exception_type": "CUSTOMS_HOLD", "severity": "CRITICAL", "status": "OPEN", "reported_at": "2026-10-11T08:30:00", "description": "Shipment is held at customs and the document packet may be incomplete."},
    {"case_id": "CASE-20260004", "shipment_id": "SHP-1004", "exception_type": "MISROUTE", "severity": "MEDIUM", "status": "OPEN", "reported_at": "2026-10-10T11:45:00", "description": "Tracking suggests an unexpected terminal and a route deviation."},
    {"case_id": "CASE-20260005", "shipment_id": "SHP-1005", "exception_type": "REFUSED_DELIVERY", "severity": "MEDIUM", "status": "OPEN", "reported_at": "2026-10-11T15:20:00", "description": "Delivery was not completed because the consignee was unavailable."},
    {"case_id": "CASE-20260006", "shipment_id": "SHP-1006", "exception_type": "DAMAGE", "severity": "CRITICAL", "status": "OPEN", "reported_at": "2026-10-08T12:05:00", "description": "High-value industrial equipment arrived damaged; a substantial carrier claim may be warranted."},
    {"case_id": "CASE-20260007", "shipment_id": "SHP-1007", "exception_type": "DELAY", "severity": "HIGH", "status": "OPEN", "reported_at": "2026-10-13T13:00:00", "description": "Medical supplies arrived two days late during a documented severe weather event."},
    {"case_id": "CASE-20260008", "shipment_id": "SHP-1008", "exception_type": "CUSTOMS_HOLD", "severity": "HIGH", "status": "OPEN", "reported_at": "2026-10-13T14:10:00", "description": "Documents appear complete, but customs clearance is waiting for duty settlement confirmation."},
    {"case_id": "CASE-20260009", "shipment_id": "SHP-1009", "exception_type": "DAMAGE", "severity": "HIGH", "status": "OPEN", "reported_at": "2026-10-14T09:35:00", "description": "Receiver reported damaged parts, but the formal damage report is missing."},
    {"case_id": "CASE-20260010", "shipment_id": "SHP-1010", "exception_type": "MISROUTE", "severity": "LOW", "status": "OPEN", "reported_at": "2026-10-16T16:10:00", "description": "An automated alert flagged a possible deviation; tracking should confirm whether it was real."},
]
