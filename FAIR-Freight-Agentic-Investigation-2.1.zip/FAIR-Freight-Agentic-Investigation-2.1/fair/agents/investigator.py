"""Agent 2/5: construct an exception-specific, allow-listed investigation plan."""
from __future__ import annotations

from typing import Any

from ..evidence import build_plan
from ..llm import propose_tool_order


class InvestigatorAgent:
    name = "Investigator Agent"
    number = 2

    def run(self, ctx: dict[str, Any]) -> dict[str, Any]:
        if not ctx.get("triage", {}).get("supported", False):
            raise ValueError("Investigation planning is blocked for an unsupported exception type.")
        plan = build_plan(ctx["triage"]["exception_type"])
        ctx["investigator_source"] = "deterministic-policy-plan"
        ctx["investigator_note"] = ""
        if ctx.get("llm_mode") == "ollama":
            order, note = propose_tool_order(ctx["case"], ctx["shipment"], plan, model=ctx.get("llm_model", "llama3.2"))
            ctx["investigator_note"] = note
            if order:
                by_name = {item["tool"]: item for item in plan}
                plan = [by_name[name] for name in order]
                ctx["investigator_source"] = "ollama-order-validated-against-allow-list"
            else:
                ctx["investigator_source"] = "deterministic-fallback"
        ctx["plan"] = plan
        ctx.setdefault("agent_status", {})[self.name] = "COMPLETED"
        return {"tools": [step["tool"] for step in plan], "critical_tools": [step["tool"] for step in plan if step["critical"]],
                "source": ctx["investigator_source"], "note": ctx["investigator_note"]}
