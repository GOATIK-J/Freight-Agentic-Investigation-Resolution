"""Agent 3/5: collect source-tagged evidence and identify evidence gaps."""
from __future__ import annotations

from typing import Any

from ..evidence import collect_evidence


class EvidenceCollectorAgent:
    name = "Evidence Collector Agent"
    number = 3

    def run(self, ctx: dict[str, Any]) -> dict[str, Any]:
        bundle = collect_evidence(ctx.get("plan", []), ctx["shipment"], retries=2)
        gaps = [item["tool_name"] for item in bundle if item.get("status") != "RETRIEVED"]
        total = len(bundle)
        retrieved = total - len(gaps)
        gap_ratio = len(gaps) / total if total else 1.0
        critical_gap = any(item.get("critical") and item.get("status") != "RETRIEVED" for item in bundle)
        ctx["bundle"] = bundle
        ctx["evidence_gaps"] = gaps
        ctx["gap_ratio"] = gap_ratio
        ctx["critical_gap"] = critical_gap
        ctx["evidence_quality"] = {
            "retrieved": retrieved, "total": total, "gap_ratio": gap_ratio,
            "completeness": 0.0 if total == 0 else round(retrieved / total, 4),
            "critical_missing": [item["tool_name"] for item in bundle if item.get("critical") and item.get("status") != "RETRIEVED"],
        }
        if critical_gap:
            ctx["human_review_reasons"] = ["Critical evidence missing: " + ", ".join(gaps) + ". Automated resolution is blocked."]
            ctx["requires_human_review"] = True
        ctx.setdefault("agent_status", {})[self.name] = "COMPLETED_WITH_GAPS" if gaps else "COMPLETED"
        return ctx["evidence_quality"]
