"""Agent 4/5: propose a constrained resolution; never execute real-world actions."""
from __future__ import annotations

from typing import Any

from ..llm import propose_resolution
from ..policy import ALLOWED_ACTIONS, compute_resolution, inject_demo_fault, review_reasons


class ResolverAgent:
    name = "Resolver Agent"
    number = 4

    def run(self, ctx: dict[str, Any]) -> dict[str, Any]:
        ctx["attempt"] = int(ctx.get("attempt", 0)) + 1
        # Deterministic policy is the baseline and remains authoritative for amount/cap checks.
        resolution = compute_resolution(ctx["case"], ctx["shipment"], ctx["bundle"])
        ctx["resolver_source"] = "deterministic-policy"
        ctx["resolver_note"] = ""
        if ctx.get("llm_mode") == "ollama":
            proposal, note = propose_resolution(
                ctx["case"], ctx["shipment"], ctx["bundle"],
                ALLOWED_ACTIONS.get(ctx["case"]["exception_type"], set()),
                model=ctx.get("llm_model", "llama3.2"), critic_feedback=ctx.get("critic_notes", []),
            )
            ctx["resolver_note"] = note
            if proposal:
                # The candidate is not trusted until the separate Critic independently recomputes it.
                resolution.update(proposal)
                resolution["notes"] = list(resolution.get("notes", [])) + [
                    "Optional local LLM supplied a candidate; independent Critic validation is mandatory."
                ]
                ctx["resolver_source"] = "ollama-candidate-requires-critic-validation"
            else:
                ctx["resolver_source"] = "deterministic-fallback"
        fault = ctx.get("fault", "none")
        if ctx["attempt"] == 1 and fault in {"omitted_cap", "wrong_amount", "invalid_policy"}:
            resolution = inject_demo_fault(resolution, fault)
            ctx["demo_fault_applied"] = fault
        else:
            ctx["demo_fault_applied"] = None
        ctx["resolution"] = resolution
        ctx["human_review_reasons"] = review_reasons(ctx["case"], ctx["shipment"], ctx["bundle"], resolution)
        ctx["requires_human_review"] = bool(ctx["human_review_reasons"])
        ctx.setdefault("agent_status", {})[self.name] = "COMPLETED"
        return {
            "attempt": ctx["attempt"], "action": resolution.get("action"), "amount": resolution.get("amount"),
            "uncapped_amount": resolution.get("uncapped_amount"), "confidence": resolution.get("confidence"),
            "source": ctx["resolver_source"], "feedback_from_critic": list(ctx.get("critic_notes", [])),
        }
