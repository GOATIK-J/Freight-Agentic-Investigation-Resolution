"""The five and only five F.A.I.R. agents.

Human approval, retries, and final status routing are orchestration controls,
not additional agents.
"""
from .triage import TriageAgent
from .investigator import InvestigatorAgent
from .evidence_collector import EvidenceCollectorAgent
from .resolver import ResolverAgent
from .critic import CriticAgent

AGENT_NAMES = (
    "Triage Agent",
    "Investigator Agent",
    "Evidence Collector Agent",
    "Resolver Agent",
    "Critic Agent",
)

__all__ = ["TriageAgent", "InvestigatorAgent", "EvidenceCollectorAgent", "ResolverAgent", "CriticAgent", "AGENT_NAMES"]
