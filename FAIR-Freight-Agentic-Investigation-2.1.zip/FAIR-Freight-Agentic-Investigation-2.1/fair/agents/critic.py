"""Agent 5/5: independently validate the Resolver proposal against evidence and policy."""
from __future__ import annotations

from typing import Any

from ..policy import critique


class CriticAgent:
    name = "Critic Agent"
    number = 5

    def run(self, ctx: dict[str, Any]) -> dict[str, Any]:
        if not ctx.get("resolution"):
            raise ValueError("Critic cannot validate a missing resolution proposal.")
        result = critique(ctx["case"], ctx["shipment"], ctx["bundle"], ctx["resolution"])
        ctx["critic_verdict"] = result["verdict"]
        ctx["critic_checks"] = result["checks"]
        ctx["critic_notes"] = result["notes"]
        if result["verdict"] == "FAIL":
            ctx.setdefault("rejected_attempts", []).append({
                "attempt": ctx["attempt"],
                "amount": ctx["resolution"].get("amount"),
                "failed_checks": result["notes"],
            })
        ctx.setdefault("agent_status", {})[self.name] = "COMPLETED" if result["verdict"] == "PASS" else "COMPLETED_WITH_FAILURES"
        return {"verdict": result["verdict"], "checks": result["checks"], "notes": result["notes"]}
