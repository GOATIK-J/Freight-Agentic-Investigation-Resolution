"""Agent 1/5: cross-check the incoming exception label and prioritize the case."""
from __future__ import annotations

import re
from typing import Any

from ..evidence import TOOLS_BY_EXCEPTION

# Deterministic keyword signals are an explainable triage aid, not a trained classifier.
# The source-of-record category remains authoritative; contradictory signals trigger review.
SIGNALS: dict[str, tuple[str, ...]] = {
    "DAMAGE": (r"\bdamag(?:e|ed|ing)\b", r"\bcrushed\b", r"\bwater intrusion\b", r"\bbroken\b", r"\bwater[- ]stained\b"),
    "DELAY": (r"\blat(?:e|er)\b", r"\bdelay(?:ed|s)?\b", r"\bafter the promised\b", r"\bweather[- ]related disruption\b"),
    "CUSTOMS_HOLD": (r"\bcustoms\b", r"\bdut(?:y|ies)\b", r"\bclearance\b", r"\bheld at customs\b"),
    "MISROUTE": (r"\bmisroute\b", r"\broute deviation\b", r"\bunexpected terminal\b", r"\bdeviation\b", r"\boff[- ]route\b"),
    "REFUSED_DELIVERY": (r"\brefus(?:ed|al)\b", r"\bconsignee unavailable\b", r"\brecipient unavailable\b", r"\bdelivery attempt\b", r"\bnot completed\b"),
}


class TriageAgent:
    name = "Triage Agent"
    number = 1

    @staticmethod
    def _infer_type(description: str) -> tuple[str | None, dict[str, int], bool]:
        text = description.casefold()
        scores = {kind: sum(1 for pattern in patterns if re.search(pattern, text)) for kind, patterns in SIGNALS.items()}
        positive = {kind: score for kind, score in scores.items() if score > 0}
        if not positive:
            return None, scores, False
        ordered = sorted(positive.items(), key=lambda item: item[1], reverse=True)
        # Ambiguous ties are intentionally routed to human review rather than guessed.
        if len(ordered) > 1 and ordered[0][1] == ordered[1][1]:
            return None, scores, True
        return ordered[0][0], scores, False

    def run(self, ctx: dict[str, Any]) -> dict[str, Any]:
        case = ctx["case"]
        shipment = ctx["shipment"]
        exception_type = str(case.get("exception_type", "UNKNOWN")).upper()
        severity = str(case.get("severity", "MEDIUM")).upper()
        supported = exception_type in TOOLS_BY_EXCEPTION
        inferred_type, signal_scores, classification_ambiguous = self._infer_type(str(case.get("description", "")))
        classification_consistent = not classification_ambiguous and (inferred_type is None or inferred_type == exception_type)
        severity_points = {"LOW": 20, "MEDIUM": 42, "HIGH": 68, "CRITICAL": 88}.get(severity, 50)
        cargo_value = max(0.0, float(shipment.get("cargo_value", 0) or 0))
        cargo_points = 12 if cargo_value >= 100_000 else 8 if cargo_value >= 50_000 else 5 if cargo_value >= 20_000 else 2
        tier = str(shipment.get("customer_tier", "Standard"))
        tier_points = {"Standard": 0, "Premium": 4, "Strategic": 8}.get(tier, 2)
        score = min(100, severity_points + cargo_points + tier_points)
        priority = "CRITICAL" if score >= 90 or severity == "CRITICAL" else "HIGH" if score >= 70 else "MEDIUM" if score >= 45 else "LOW"
        flags: list[str] = []
        if severity == "CRITICAL":
            flags.append("Critical severity requires a human decision")
        if tier == "Strategic":
            flags.append("Strategic customer account")
        if cargo_value >= 50_000:
            flags.append("High-value cargo")
        if not supported:
            flags.append(f"Unsupported exception type: {exception_type}")
        if classification_ambiguous:
            flags.append("Description contains conflicting signals for multiple exception types; automated handling is blocked")
        elif inferred_type and not classification_consistent:
            flags.append(f"Description suggests {inferred_type}, but the case record says {exception_type}; automated handling is blocked")
        if not str(case.get("description", "")).strip():
            flags.append("Case description missing")
        reasons = []
        if not supported:
            reasons.append("Unsupported exception type; automated handling is not configured.")
        if classification_ambiguous:
            reasons.append("Triage uncertainty: description contains equally strong signals for multiple exception types.")
        elif not classification_consistent:
            reasons.append(f"Triage mismatch: description signals {inferred_type}, while the case record says {exception_type}.")
        ctx["triage"] = {
            "exception_type": exception_type,
            "inferred_type_hint": inferred_type,
            "signal_scores": signal_scores,
            "classification_consistent": classification_consistent,
            "classification_ambiguous": classification_ambiguous,
            "severity": severity,
            "priority": priority,
            "priority_score": score,
            "supported": supported,
            "risk_flags": flags,
            "rationale": (
                f"Record category {exception_type.replace('_', ' ').title()} was cross-checked against description signals; "
                f"severity, cargo value and customer tier produce priority {priority} ({score}/100)."
                if supported and classification_consistent else
                "The exception category is unsupported or conflicts with the description; automated handling is blocked until a reviewer confirms the correct classification."
            ),
        }
        if reasons:
            ctx["human_review_reasons"] = reasons
            ctx["requires_human_review"] = True
        ctx.setdefault("agent_status", {})[self.name] = "COMPLETED" if supported and classification_consistent else "COMPLETED_WITH_FLAGS"
        return ctx["triage"]
