"""Deterministic policy outcomes, caps, and independent Critic checks."""
from __future__ import annotations

from datetime import date
from typing import Any

AUTHORITY_LIMIT = 10_000.0
DEFAULT_LIABILITY_CAP = 50_000.0
TIER_CEILINGS = {"Standard": 50_000.0, "Premium": 75_000.0, "Strategic": 100_000.0}
MAX_ATTEMPTS = 2
CONFIDENCE_REVIEW_THRESHOLD = 0.75

ALLOWED_ACTIONS: dict[str, set[str]] = {
    "DAMAGE": {"CARRIER_CLAIM", "REQUEST_DOCUMENTS", "NO_ACTION", "ESCALATE_TO_HUMAN"},
    "DELAY": {"CUSTOMER_CREDIT", "NO_ACTION", "REVIEW_FORCE_MAJEURE", "CARRIER_INVESTIGATION", "ESCALATE_TO_HUMAN"},
    "CUSTOMS_HOLD": {"REQUEST_DOCUMENTS", "VERIFY_DUTY_STATUS", "SUBMIT_CLEARANCE", "NO_ACTION", "ESCALATE_TO_HUMAN"},
    "MISROUTE": {"CARRIER_INVESTIGATION", "NO_ACTION", "ESCALATE_TO_HUMAN"},
    "REFUSED_DELIVERY": {"RESCHEDULE_DELIVERY", "REQUEST_DOCUMENTS", "CARRIER_INVESTIGATION", "NO_ACTION", "ESCALATE_TO_HUMAN"},
}

VALID_POLICY_REFERENCES = {
    "3.1", "3.2", "3.3", "4.1", "4.2", "5.1", "6.2", "SLA-1", "OPS-ROUTE-1",
    "CUSTOMS-1", "DELIVERY-1", "HUMAN-REVIEW",
}


def _evidence_map(bundle: list[dict[str, Any]]) -> dict[str, dict[str, Any]]:
    return {item["tool_name"]: item.get("details", {}) for item in bundle if item.get("status") == "RETRIEVED"}


def _date_days(promised: str | None, actual: str | None) -> int:
    if not promised or not actual:
        return 0
    try:
        return max(0, (date.fromisoformat(actual[:10]) - date.fromisoformat(promised[:10])).days)
    except (TypeError, ValueError):
        return 0


def compute_resolution(case: dict[str, Any], shipment: dict[str, Any], bundle: list[dict[str, Any]]) -> dict[str, Any]:
    """Return a deterministic proposal. This function never executes real actions or payments."""
    evidence = _evidence_map(bundle)
    exception_type = case["exception_type"]
    contract = evidence.get("get_contract_terms", {})
    authority_limit = float(contract.get("authority_limit", AUTHORITY_LIMIT) or AUTHORITY_LIMIT)
    tier_ceiling = float(TIER_CEILINGS.get(shipment.get("customer_tier", "Standard"), DEFAULT_LIABILITY_CAP))
    contract_cap = float(contract.get("liability_cap", DEFAULT_LIABILITY_CAP) or DEFAULT_LIABILITY_CAP)
    effective_cap = max(0.0, min(contract_cap, tier_ceiling, float(shipment.get("cargo_value", 0.0))))
    action = "NO_ACTION"
    root_cause = "No actionable exception was confirmed"
    amount = 0.0
    uncapped_amount = 0.0
    rationale = "Available evidence does not support a financial or operational corrective action."
    refs: list[str] = []
    notes: list[str] = []

    if exception_type == "DAMAGE":
        pod = evidence.get("get_pod", {})
        damage = evidence.get("get_damage_report", {})
        if pod.get("damage_notation") and damage.get("confirmed"):
            claimed_loss = min(max(float(damage.get("estimated_loss", 0)), 0.0), max(float(shipment.get("cargo_value", 0)), 0.0))
            salvage = max(float(damage.get("salvage_value", 0)), 0.0)
            freight_refund = max(float(damage.get("freight_refund", 0)), 0.0)
            deductible = max(float(damage.get("deductible", 0)), 0.0)
            uncapped_amount = max(0.0, claimed_loss - salvage + freight_refund - deductible)
            amount = min(uncapped_amount, effective_cap)
            action = "CARRIER_CLAIM"
            root_cause = "Cargo damage recorded during carrier custody"
            rationale = (f"Damage is confirmed by the report and delivery notation. Adjusted estimate is "
                         f"${uncapped_amount:,.2f} before the ${effective_cap:,.2f} effective cap.")
            refs = ["3.1", "3.2", "3.3", "4.1", "4.2", "6.2"]
            if uncapped_amount > effective_cap:
                notes.append("The per-shipment and customer-tier cap was applied before any human approval.")
        else:
            action = "REQUEST_DOCUMENTS"
            root_cause = "Damage claim lacks consistent supporting evidence"
            rationale = "Request a complete proof of delivery and verified damage report before proposing liability."
            refs = ["6.2"]
            notes.append("No payment or final liability decision is proposed without required damage evidence.")

    elif exception_type == "DELAY":
        tracking = evidence.get("get_tracking", {})
        service = evidence.get("get_service_level", {})
        promised = tracking.get("promised_delivery") or shipment.get("promised_delivery")
        actual = tracking.get("actual_delivery") or shipment.get("actual_delivery")
        late_days = _date_days(promised, actual)
        weather_item = next((x for x in bundle if x["tool_name"] == "get_weather"), None)
        weather = evidence.get("get_weather", {})
        if late_days == 0:
            action, root_cause = "NO_ACTION", "No delivery delay was confirmed"
            rationale = "Tracking shows delivery on or before the promised date."
            refs = ["SLA-1"]
        elif weather_item and weather_item.get("status") == "RETRIEVED" and weather.get("verified") and int(weather.get("max_severity", 0)) >= int(contract.get("severe_weather_level", 4)):
            action, root_cause = "REVIEW_FORCE_MAJEURE", "Severe weather may have contributed to delay"
            rationale = "Verified severe weather meets the contract's review threshold; causation and contractual applicability require a human decision."
            refs = ["5.1", "SLA-1"]
            notes.append("The system does not automatically deny a claim solely because severe weather was reported.")
        else:
            credit_per_day = max(float(service.get("credit_per_day", 0)), 0.0)
            maximum_credit = max(float(service.get("maximum_credit", 0)), 0.0)
            uncapped_amount = late_days * credit_per_day
            amount = min(uncapped_amount, maximum_credit, effective_cap)
            action, root_cause = "CUSTOMER_CREDIT", f"Delivery was {late_days} day(s) late"
            rationale = f"Tracking confirms {late_days} late day(s); the synthetic service-level rule yields ${amount:,.2f}."
            refs = ["SLA-1"]
            if not (weather_item and weather_item.get("status") == "RETRIEVED" and weather.get("verified")):
                notes.append("Weather was not independently verified; no force-majeure denial was applied.")

    elif exception_type == "CUSTOMS_HOLD":
        documents = evidence.get("get_customs_documents", {})
        customs = evidence.get("get_customs_status", {})
        missing = documents.get("missing_documents", [])
        status = str(customs.get("status", "UNKNOWN")).upper()
        if missing:
            action = "REQUEST_DOCUMENTS"
            root_cause = "Customs release blocked by incomplete documentation"
            rationale = "The document check found missing items: " + ", ".join(str(x) for x in missing) + "."
            refs = ["CUSTOMS-1"]
            notes.append("Submit only validated documents through the carrier or customs process; this demo does not transmit documents.")
        elif status == "DUTY_PENDING" or not customs.get("duties_paid", False):
            action = "VERIFY_DUTY_STATUS"
            root_cause = "Customs release awaits duty settlement confirmation"
            rationale = "The documents appear complete, but the duty-status record does not confirm settlement."
            refs = ["CUSTOMS-1"]
        elif status == "CLEARED":
            action = "NO_ACTION"
            root_cause = "Customs clearance is complete"
            rationale = "The customs status record shows clearance; close the exception after operational confirmation."
            refs = ["CUSTOMS-1"]
        else:
            action = "SUBMIT_CLEARANCE"
            root_cause = "Customs hold requires a documented clearance follow-up"
            rationale = f"Customs status is {status}; follow up with the responsible broker using validated documents."
            refs = ["CUSTOMS-1"]

    elif exception_type == "MISROUTE":
        route = evidence.get("get_route_check", {})
        tracking = evidence.get("get_tracking", {})
        if route.get("deviation"):
            action = "CARRIER_INVESTIGATION"
            root_cause = "Recorded route differs from planned corridor"
            rationale = (f"Expected route: {route.get('expected_route', 'not supplied')}. "
                         f"Actual route: {route.get('actual_route', 'not supplied')}. Request carrier explanation and confirm impact.")
            refs = ["OPS-ROUTE-1"]
            notes.append(f"Tracking status: {tracking.get('status', 'unknown')}.")
        else:
            action = "NO_ACTION"
            root_cause = "Route deviation not confirmed"
            rationale = "Tracking and the route check agree; the alert appears unsupported by available evidence."
            refs = ["OPS-ROUTE-1"]

    elif exception_type == "REFUSED_DELIVERY":
        attempt = evidence.get("get_delivery_attempts", {})
        reason = str(attempt.get("refusal_reason", "unknown")).lower()
        if reason in {"consignee_unavailable", "recipient_unavailable"} and attempt.get("next_attempt_available"):
            action = "RESCHEDULE_DELIVERY"
            root_cause = "Consignee was unavailable at the recorded delivery attempt"
            rationale = "The carrier recorded recipient unavailability and a further attempt is available; coordinate a new delivery window."
            refs = ["DELIVERY-1"]
        elif reason in {"missing_documents", "paperwork_issue"}:
            action = "REQUEST_DOCUMENTS"
            root_cause = "Delivery refusal appears related to incomplete paperwork"
            rationale = "Confirm and supply the missing delivery documents before re-attempting delivery."
            refs = ["DELIVERY-1"]
        else:
            action = "CARRIER_INVESTIGATION"
            root_cause = "Refusal reason needs further verification"
            rationale = f"Recorded refusal reason is {reason}; ask the carrier to confirm the reason and next operational step."
            refs = ["DELIVERY-1"]
    else:
        raise ValueError(f"Unsupported exception type: {exception_type}")

    retrieved_count = sum(1 for item in bundle if item.get("status") == "RETRIEVED")
    gap_ratio = 1.0 - (retrieved_count / len(bundle)) if bundle else 1.0
    confidence = round(max(0.35, min(0.96, 0.62 + 0.32 * (1.0 - gap_ratio))), 2)
    if gap_ratio > 0:
        notes.append(f"Evidence gap ratio: {gap_ratio:.0%}; confidence reflects evidence availability, not model self-assessment.")
    return {
        "root_cause": root_cause, "action": action, "amount": round(amount, 2), "uncapped_amount": round(uncapped_amount, 2),
        "confidence": confidence, "rationale": rationale, "policy_references": refs, "notes": notes,
        "effective_cap": round(effective_cap, 2), "authority_limit": authority_limit,
    }


def review_reasons(case: dict[str, Any], shipment: dict[str, Any], bundle: list[dict[str, Any]], resolution: dict[str, Any]) -> list[str]:
    reasons: list[str] = []
    if case.get("severity") == "CRITICAL":
        reasons.append("Critical-severity exception requires a human decision.")
    if shipment.get("customer_tier") == "Strategic":
        reasons.append("Strategic customer account requires human review.")
    if float(resolution.get("amount", 0)) > float(resolution.get("authority_limit", AUTHORITY_LIMIT)):
        reasons.append(f"Proposed amount exceeds the ${float(resolution.get('authority_limit', AUTHORITY_LIMIT)):,.0f} approval authority limit.")
    if float(resolution.get("confidence", 0)) < CONFIDENCE_REVIEW_THRESHOLD:
        reasons.append("Evidence-derived confidence is below the review threshold.")
    gap_count = sum(1 for item in bundle if item.get("status") != "RETRIEVED")
    gap_ratio = gap_count / len(bundle) if bundle else 1.0
    if gap_ratio > 0.30:
        reasons.append(f"Evidence gap ratio is {gap_ratio:.0%}, above the 30% threshold.")
    if resolution.get("action") in {"REVIEW_FORCE_MAJEURE", "ESCALATE_TO_HUMAN"}:
        reasons.append("Resolution policy explicitly requires human assessment.")
    if case.get("exception_type") == "DELAY":
        weather = next((x for x in bundle if x["tool_name"] == "get_weather"), None)
        if not weather or weather.get("status") != "RETRIEVED" or not weather.get("details", {}).get("verified"):
            reasons.append("Weather was not independently verified; force-majeure treatment remains unresolved.")
    return reasons


def inject_demo_fault(resolution: dict[str, Any], fault: str) -> dict[str, Any]:
    """Fault injection is restricted to demonstration mode and the first attempt only."""
    changed = dict(resolution)
    changed["policy_references"] = list(resolution.get("policy_references", []))
    if fault == "omitted_cap":
        changed["amount"] = round(float(resolution.get("uncapped_amount", resolution.get("amount", 0))), 2)
        changed["notes"] = list(changed.get("notes", [])) + ["DEMO FAULT: cap step intentionally omitted on first attempt."]
    elif fault == "wrong_amount":
        changed["amount"] = round(float(resolution.get("amount", 0)) + 5000.0, 2)
        changed["notes"] = list(changed.get("notes", [])) + ["DEMO FAULT: amount intentionally perturbed on first attempt."]
    elif fault == "invalid_policy":
        changed["policy_references"].append("SECTION-99.9")
        changed["notes"] = list(changed.get("notes", [])) + ["DEMO FAULT: invalid policy reference inserted on first attempt."]
    return changed


def _independent_recompute(case: dict[str, Any], shipment: dict[str, Any], bundle: list[dict[str, Any]]) -> dict[str, Any]:
    """Critic-side verifier: derive action and amount directly from evidence, not the Resolver's function."""
    ev = _evidence_map(bundle)
    kind = case.get("exception_type")
    contract = ev.get("get_contract_terms", {})
    tier = TIER_CEILINGS.get(shipment.get("customer_tier", "Standard"), DEFAULT_LIABILITY_CAP)
    cap = max(0.0, min(float(contract.get("liability_cap", DEFAULT_LIABILITY_CAP) or DEFAULT_LIABILITY_CAP),
                       float(tier), float(shipment.get("cargo_value", 0.0))))
    expected_action = "NO_ACTION"
    expected_amount = 0.0

    # Intentionally separate from compute_resolution(): these checks are the Critic's second calculation path.
    if kind == "DAMAGE":
        pod, report = ev.get("get_pod", {}), ev.get("get_damage_report", {})
        if pod.get("damage_notation") and report.get("confirmed"):
            invoiced_or_claimed = min(max(float(report.get("estimated_loss", 0)), 0.0), max(float(shipment.get("cargo_value", 0)), 0.0))
            adjusted = invoiced_or_claimed - max(float(report.get("salvage_value", 0)), 0.0)
            adjusted += max(float(report.get("freight_refund", 0)), 0.0)
            adjusted -= max(float(report.get("deductible", 0)), 0.0)
            expected_action, expected_amount = "CARRIER_CLAIM", round(min(max(adjusted, 0.0), cap), 2)
        else:
            expected_action = "REQUEST_DOCUMENTS"
    elif kind == "DELAY":
        tracking = ev.get("get_tracking", {})
        service = ev.get("get_service_level", {})
        days_late = _date_days(tracking.get("promised_delivery") or shipment.get("promised_delivery"),
                               tracking.get("actual_delivery") or shipment.get("actual_delivery"))
        weather_record = next((x for x in bundle if x.get("tool_name") == "get_weather"), None)
        weather = ev.get("get_weather", {})
        severity_threshold = int(contract.get("severe_weather_level", 4))
        if days_late <= 0:
            expected_action = "NO_ACTION"
        elif weather_record and weather_record.get("status") == "RETRIEVED" and weather.get("verified") and int(weather.get("max_severity", 0)) >= severity_threshold:
            expected_action = "REVIEW_FORCE_MAJEURE"
        else:
            per_day = max(float(service.get("credit_per_day", 0)), 0.0)
            max_credit = max(float(service.get("maximum_credit", 0)), 0.0)
            expected_action = "CUSTOMER_CREDIT"
            expected_amount = round(min(days_late * per_day, max_credit, cap), 2)
    elif kind == "CUSTOMS_HOLD":
        docs = ev.get("get_customs_documents", {})
        customs = ev.get("get_customs_status", {})
        if docs.get("missing_documents", []):
            expected_action = "REQUEST_DOCUMENTS"
        elif str(customs.get("status", "UNKNOWN")).upper() == "DUTY_PENDING" or not customs.get("duties_paid", False):
            expected_action = "VERIFY_DUTY_STATUS"
        elif str(customs.get("status", "UNKNOWN")).upper() == "CLEARED":
            expected_action = "NO_ACTION"
        else:
            expected_action = "SUBMIT_CLEARANCE"
    elif kind == "MISROUTE":
        expected_action = "CARRIER_INVESTIGATION" if ev.get("get_route_check", {}).get("deviation") else "NO_ACTION"
    elif kind == "REFUSED_DELIVERY":
        attempts = ev.get("get_delivery_attempts", {})
        reason = str(attempts.get("refusal_reason", "unknown")).lower()
        if reason in {"consignee_unavailable", "recipient_unavailable"} and attempts.get("next_attempt_available"):
            expected_action = "RESCHEDULE_DELIVERY"
        elif reason in {"missing_documents", "paperwork_issue"}:
            expected_action = "REQUEST_DOCUMENTS"
        else:
            expected_action = "CARRIER_INVESTIGATION"
    return {"action": expected_action, "amount": expected_amount, "effective_cap": cap}


def critique(case: dict[str, Any], shipment: dict[str, Any], bundle: list[dict[str, Any]], resolution: dict[str, Any]) -> dict[str, Any]:
    """Critic independently derives action and money from source evidence, then checks policy invariants."""
    expected = _independent_recompute(case, shipment, bundle)
    checks: list[dict[str, Any]] = []

    def add(name: str, passed: bool, detail: str) -> None:
        checks.append({"check": name, "passed": bool(passed), "detail": detail})

    action_allowed = resolution.get("action") in ALLOWED_ACTIONS.get(case.get("exception_type"), set())
    add("Action is allow-listed for this exception", action_allowed,
        "action allowed" if action_allowed else f"Action {resolution.get('action')!r} is not allowed for {case.get('exception_type')}.")
    action_expected = resolution.get("action") == expected["action"]
    add("Action matches independent evidence assessment", action_expected,
        f"proposed {resolution.get('action')}; independently expected {expected['action']}")
    refs = resolution.get("policy_references", [])
    invalid_refs = [ref for ref in refs if ref not in VALID_POLICY_REFERENCES]
    add("Policy references exist", not invalid_refs, "all references are valid" if not invalid_refs else f"Unknown reference(s): {', '.join(invalid_refs)}")
    try:
        actual_amount = float(resolution.get("amount"))
        expected_amount = float(expected.get("amount", 0))
        same_amount = abs(actual_amount - expected_amount) <= 0.01
        nonnegative = actual_amount >= 0
    except (TypeError, ValueError):
        actual_amount, expected_amount, same_amount, nonnegative = float("nan"), float(expected.get("amount", 0)), False, False
    add("Amount matches independent policy recomputation", same_amount,
        f"proposed ${actual_amount:,.2f}; independently expected ${expected_amount:,.2f}")
    add("Financial amount is non-negative", nonnegative, "amount is non-negative" if nonnegative else "amount is negative or not numeric")
    cap = float(expected.get("effective_cap", DEFAULT_LIABILITY_CAP))
    capped = actual_amount <= cap + 0.01
    add("Financial amount respects effective cap", capped, f"amount ${actual_amount:,.2f}; effective cap ${cap:,.2f}")
    rationale_ok = isinstance(resolution.get("rationale"), str) and bool(resolution.get("rationale", "").strip())
    add("Rationale is recorded", rationale_ok, "rationale supplied" if rationale_ok else "resolution has no explanation")
    failed = [item for item in checks if not item["passed"]]
    return {"verdict": "FAIL" if failed else "PASS", "checks": checks,
            "notes": [f"{item['check']}: {item['detail']}" for item in failed], "expected": expected}
