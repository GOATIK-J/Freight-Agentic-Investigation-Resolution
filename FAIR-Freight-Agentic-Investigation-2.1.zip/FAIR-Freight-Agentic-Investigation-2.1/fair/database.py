"""SQLite persistence and tamper-evident audit event chain for F.A.I.R. 2.1."""
from __future__ import annotations

import hashlib
import json
import os
import sqlite3
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from .seed import CASES, SHIPMENTS

PROJECT_ROOT = Path(__file__).resolve().parents[1]
DB_PATH: Path | str = Path(os.environ.get("FAIR_DB_PATH", PROJECT_ROOT / "data" / "fair_freight.db"))


def utc_now() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat()


def get_connection() -> sqlite3.Connection:
    path = Path(DB_PATH)
    path.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(path, timeout=15)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    conn.execute("PRAGMA busy_timeout = 15000")
    return conn


def init_db() -> None:
    with get_connection() as conn:
        conn.executescript(
            """
            CREATE TABLE IF NOT EXISTS shipments (
                shipment_id TEXT PRIMARY KEY,
                carrier_id TEXT NOT NULL,
                origin TEXT NOT NULL,
                destination TEXT NOT NULL,
                commodity TEXT NOT NULL,
                cargo_value REAL NOT NULL CHECK (cargo_value >= 0),
                customer_tier TEXT NOT NULL,
                ship_date TEXT,
                promised_delivery TEXT,
                actual_delivery TEXT,
                evidence_json TEXT NOT NULL
            );
            CREATE TABLE IF NOT EXISTS exceptions (
                case_id TEXT PRIMARY KEY,
                shipment_id TEXT NOT NULL REFERENCES shipments(shipment_id),
                exception_type TEXT NOT NULL,
                severity TEXT NOT NULL,
                status TEXT NOT NULL DEFAULT 'OPEN',
                reported_at TEXT NOT NULL,
                description TEXT NOT NULL
            );
            CREATE TABLE IF NOT EXISTS investigations (
                run_id TEXT PRIMARY KEY,
                case_id TEXT NOT NULL REFERENCES exceptions(case_id),
                started_at TEXT NOT NULL,
                completed_at TEXT,
                status TEXT NOT NULL,
                result_json TEXT NOT NULL
            );
            CREATE INDEX IF NOT EXISTS idx_investigations_case_started ON investigations(case_id, started_at DESC);
            CREATE TABLE IF NOT EXISTS audit_events (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                run_id TEXT NOT NULL,
                case_id TEXT NOT NULL,
                timestamp TEXT NOT NULL,
                agent TEXT NOT NULL,
                event_type TEXT NOT NULL,
                status TEXT NOT NULL,
                details_json TEXT NOT NULL,
                prev_hash TEXT NOT NULL,
                event_hash TEXT NOT NULL
            );
            CREATE INDEX IF NOT EXISTS idx_audit_case_id ON audit_events(case_id, id);
            CREATE INDEX IF NOT EXISTS idx_audit_run_id ON audit_events(run_id, id);
            CREATE TABLE IF NOT EXISTS human_decisions (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                run_id TEXT NOT NULL,
                case_id TEXT NOT NULL,
                timestamp TEXT NOT NULL,
                reviewer TEXT NOT NULL,
                decision TEXT NOT NULL,
                note TEXT NOT NULL,
                override_action TEXT
            );
            """
        )
        count = conn.execute("SELECT COUNT(*) FROM exceptions").fetchone()[0]
        if count == 0:
            for item in SHIPMENTS:
                conn.execute(
                    """INSERT INTO shipments (shipment_id, carrier_id, origin, destination, commodity, cargo_value,
                       customer_tier, ship_date, promised_delivery, actual_delivery, evidence_json)
                       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                    (item["shipment_id"], item["carrier_id"], item["origin"], item["destination"], item["commodity"],
                     item["cargo_value"], item["customer_tier"], item.get("ship_date"), item.get("promised_delivery"),
                     item.get("actual_delivery"), json.dumps(item["evidence"], sort_keys=True)),
                )
            for item in CASES:
                conn.execute(
                    """INSERT INTO exceptions (case_id, shipment_id, exception_type, severity, status, reported_at, description)
                       VALUES (?, ?, ?, ?, ?, ?, ?)""",
                    (item["case_id"], item["shipment_id"], item["exception_type"], item["severity"], item["status"], item["reported_at"], item["description"]),
                )


def list_cases(filters: dict[str, str] | None = None) -> list[dict[str, Any]]:
    query = """SELECT e.*, s.carrier_id, s.origin, s.destination, s.commodity, s.cargo_value, s.customer_tier,
                      s.promised_delivery, s.actual_delivery
               FROM exceptions e JOIN shipments s ON e.shipment_id = s.shipment_id WHERE 1=1"""
    args: list[Any] = []
    filters = filters or {}
    for key, col in (("exception_type", "e.exception_type"), ("severity", "e.severity"), ("status", "e.status")):
        value = filters.get(key)
        if value:
            query += f" AND {col} = ?"
            args.append(value)
    query += " ORDER BY CASE e.severity WHEN 'CRITICAL' THEN 0 WHEN 'HIGH' THEN 1 WHEN 'MEDIUM' THEN 2 ELSE 3 END, e.reported_at DESC"
    with get_connection() as conn:
        return [dict(r) for r in conn.execute(query, args).fetchall()]


def get_case_bundle(case_id: str) -> tuple[dict[str, Any], dict[str, Any]] | None:
    with get_connection() as conn:
        case = conn.execute("SELECT * FROM exceptions WHERE case_id = ?", (case_id,)).fetchone()
        if not case:
            return None
        shipment = conn.execute("SELECT * FROM shipments WHERE shipment_id = ?", (case["shipment_id"],)).fetchone()
    ship = dict(shipment)
    ship["evidence"] = json.loads(ship.pop("evidence_json"))
    return dict(case), ship


def update_case_status(case_id: str, status: str) -> None:
    with get_connection() as conn:
        conn.execute("UPDATE exceptions SET status = ? WHERE case_id = ?", (status, case_id))


def _event_payload(event: dict[str, Any]) -> dict[str, str]:
    return {k: str(event[k]) for k in ("case_id", "run_id", "timestamp", "agent", "event_type", "status", "details_json", "prev_hash")}


def record_audit_event(run_id: str, case_id: str, agent: str, event_type: str, status: str, details: Any) -> dict[str, Any]:
    timestamp = utc_now()
    details_json = json.dumps(details, sort_keys=True, separators=(",", ":"), default=str)
    with get_connection() as conn:
        row = conn.execute("SELECT event_hash FROM audit_events WHERE case_id = ? ORDER BY id DESC LIMIT 1", (case_id,)).fetchone()
        prev_hash = row["event_hash"] if row else "GENESIS"
        event = {"case_id": case_id, "run_id": run_id, "timestamp": timestamp, "agent": agent,
                 "event_type": event_type, "status": status, "details_json": details_json, "prev_hash": prev_hash}
        event_hash = hashlib.sha256(json.dumps(_event_payload(event), sort_keys=True, separators=(",", ":")).encode("utf-8")).hexdigest()
        conn.execute(
            """INSERT INTO audit_events (run_id, case_id, timestamp, agent, event_type, status, details_json, prev_hash, event_hash)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (run_id, case_id, timestamp, agent, event_type, status, details_json, prev_hash, event_hash),
        )
    return {**event, "details": json.loads(details_json), "event_hash": event_hash}


def get_audit_events(case_id: str | None = None, run_id: str | None = None) -> list[dict[str, Any]]:
    query = "SELECT * FROM audit_events WHERE 1=1"
    args: list[str] = []
    if case_id:
        query += " AND case_id = ?"
        args.append(case_id)
    if run_id:
        query += " AND run_id = ?"
        args.append(run_id)
    query += " ORDER BY id ASC"
    with get_connection() as conn:
        rows = conn.execute(query, args).fetchall()
    result = []
    for row in rows:
        item = dict(row)
        item["details"] = json.loads(item.pop("details_json"))
        result.append(item)
    return result


def verify_audit_chain(case_id: str) -> tuple[bool, str]:
    events = get_audit_events(case_id=case_id)
    previous = "GENESIS"
    for idx, ev in enumerate(events, start=1):
        stored_prev = ev["prev_hash"]
        details_json = json.dumps(ev["details"], sort_keys=True, separators=(",", ":"), default=str)
        payload = {"case_id": ev["case_id"], "run_id": ev["run_id"], "timestamp": ev["timestamp"], "agent": ev["agent"],
                   "event_type": ev["event_type"], "status": ev["status"], "details_json": details_json, "prev_hash": stored_prev}
        expected_hash = hashlib.sha256(json.dumps(_event_payload(payload), sort_keys=True, separators=(",", ":")).encode("utf-8")).hexdigest()
        if stored_prev != previous:
            return False, f"Chain link mismatch at audit event #{ev['id']} (position {idx})."
        if expected_hash != ev["event_hash"]:
            return False, f"Event hash mismatch at audit event #{ev['id']} (position {idx})."
        previous = ev["event_hash"]
    return True, f"Verified {len(events)} audit event(s)." if events else "No audit events exist for this case yet."


def save_investigation(ctx: dict[str, Any]) -> None:
    completed_at = utc_now()
    ctx["completed_at"] = completed_at
    status_map = {"PENDING_APPROVAL": "ESCALATED", "AUTO_APPROVED": "RESOLVED", "RESOLVED": "RESOLVED",
                  "APPROVED": "RESOLVED", "REJECTED": "ESCALATED", "NEEDS_EVIDENCE": "OPEN", "OVERRIDDEN": "RESOLVED", "ESCALATED": "ESCALATED"}
    with get_connection() as conn:
        conn.execute(
            """INSERT INTO investigations (run_id, case_id, started_at, completed_at, status, result_json)
               VALUES (?, ?, ?, ?, ?, ?) ON CONFLICT(run_id) DO UPDATE SET completed_at=excluded.completed_at,
               status=excluded.status, result_json=excluded.result_json""",
            (ctx["run_id"], ctx["case_id"], ctx["started_at"], completed_at, ctx["status"], json.dumps(ctx, sort_keys=True, default=str)),
        )
        conn.execute("UPDATE exceptions SET status = ? WHERE case_id = ?", (status_map.get(ctx["status"], "IN_PROGRESS"), ctx["case_id"]))


def _investigation_row(row: sqlite3.Row) -> dict[str, Any]:
    out = dict(row)
    out["result"] = json.loads(out.pop("result_json"))
    return out


def latest_investigation(case_id: str) -> dict[str, Any] | None:
    with get_connection() as conn:
        row = conn.execute("SELECT * FROM investigations WHERE case_id = ? ORDER BY started_at DESC LIMIT 1", (case_id,)).fetchone()
    return _investigation_row(row) if row else None


def get_investigation(run_id: str) -> dict[str, Any] | None:
    with get_connection() as conn:
        row = conn.execute("SELECT * FROM investigations WHERE run_id = ?", (run_id,)).fetchone()
    return _investigation_row(row) if row else None


def list_investigations() -> list[dict[str, Any]]:
    with get_connection() as conn:
        rows = conn.execute("SELECT * FROM investigations ORDER BY started_at DESC").fetchall()
    return [_investigation_row(r) for r in rows]


def pending_investigations() -> list[dict[str, Any]]:
    query = """SELECT i.* FROM investigations i
               WHERE i.status = 'PENDING_APPROVAL'
               AND i.rowid = (SELECT j.rowid FROM investigations j WHERE j.case_id = i.case_id
                              ORDER BY j.started_at DESC, j.rowid DESC LIMIT 1)
               ORDER BY i.started_at DESC, i.rowid DESC"""
    with get_connection() as conn:
        rows = conn.execute(query).fetchall()
    return [_investigation_row(r) for r in rows]


def apply_human_decision(run_id: str, decision: str, reviewer: str, note: str, override_action: str | None = None) -> dict[str, Any]:
    allowed_decisions = {"APPROVE", "REJECT", "REQUEST_EVIDENCE", "OVERRIDE"}
    if decision not in allowed_decisions:
        raise ValueError("Unsupported reviewer decision.")
    loaded = get_investigation(run_id)
    if not loaded:
        raise ValueError("Investigation run was not found.")
    result = loaded["result"]
    if result["status"] != "PENDING_APPROVAL":
        raise ValueError("This investigation is no longer waiting for a decision.")
    resolution = result.get("resolution")
    if decision == "APPROVE" and (not resolution or result.get("critic_verdict") != "PASS"):
        raise ValueError("Approval requires a proposed resolution and a passing Critic. Use Override or Request More Evidence instead.")
    if decision == "OVERRIDE":
        from .policy import ALLOWED_ACTIONS
        if override_action not in ALLOWED_ACTIONS.get(result["case"]["exception_type"], set()):
            raise ValueError("The selected override action is not allowed for this exception type.")
        if not note.strip():
            raise ValueError("A reviewer note is required for an override.")
        if resolution is None:
            result["resolution"] = {"root_cause": "Human-directed resolution", "action": override_action, "amount": 0.0,
                                    "confidence": 1.0, "rationale": "Human override; no automatic monetary action was executed.",
                                    "policy_references": ["HUMAN-REVIEW"], "notes": ["Amount is zero unless a separate verified assessment is recorded."], "uncapped_amount": 0.0}
        else:
            old_action = resolution.get("action")
            old_amount = float(resolution.get("amount", 0.0)) if override_action == old_action else 0.0
            resolution["action"] = override_action
            resolution["amount"] = old_amount
            resolution["rationale"] = f"Human override by {reviewer}. {note.strip()}"
            if override_action != old_action:
                resolution["notes"] = list(resolution.get("notes", [])) + ["Amount reset to $0 because the action changed; separately verify any financial adjustment."]
    mapping = {"APPROVE": ("APPROVED", "RESOLVED"), "REJECT": ("REJECTED", "ESCALATED"),
               "REQUEST_EVIDENCE": ("NEEDS_EVIDENCE", "OPEN"), "OVERRIDE": ("OVERRIDDEN", "RESOLVED")}
    new_status, case_status = mapping[decision]
    if decision == "OVERRIDE" and override_action == "ESCALATE_TO_HUMAN":
        case_status = "ESCALATED"
    result["status"] = new_status
    result.setdefault("human_decisions", []).append({"timestamp": utc_now(), "reviewer": reviewer, "decision": decision,
                                                        "note": note, "override_action": override_action})
    with get_connection() as conn:
        conn.execute("UPDATE investigations SET status = ?, result_json = ?, completed_at = ? WHERE run_id = ?",
                     (new_status, json.dumps(result, sort_keys=True, default=str), utc_now(), run_id))
        conn.execute("UPDATE exceptions SET status = ? WHERE case_id = ?", (case_status, result["case"]["case_id"]))
        conn.execute("INSERT INTO human_decisions (run_id, case_id, timestamp, reviewer, decision, note, override_action) VALUES (?, ?, ?, ?, ?, ?, ?)",
                     (run_id, result["case"]["case_id"], utc_now(), reviewer, decision, note, override_action))
    record_audit_event(run_id, result["case"]["case_id"], "Human Reviewer", "HUMAN_DECISION", new_status,
                       {"reviewer": reviewer, "decision": decision, "note": note, "override_action": override_action})
    return result


def dashboard_summary() -> dict[str, Any]:
    with get_connection() as conn:
        def scalar(sql: str) -> int:
            return int(conn.execute(sql).fetchone()[0])
        return {
            "shipments": scalar("SELECT COUNT(*) FROM shipments"),
            "exceptions": scalar("SELECT COUNT(*) FROM exceptions"),
            "open": scalar("SELECT COUNT(*) FROM exceptions WHERE status = 'OPEN'"),
            "in_progress": scalar("SELECT COUNT(*) FROM exceptions WHERE status = 'IN_PROGRESS'"),
            "escalated": scalar("SELECT COUNT(*) FROM exceptions WHERE status = 'ESCALATED'"),
            "resolved": scalar("SELECT COUNT(*) FROM exceptions WHERE status = 'RESOLVED'"),
            "investigations": scalar("SELECT COUNT(*) FROM investigations"),
        }
