"""F.A.I.R. orchestration with exactly five named agents.

The compiled LangGraph contains five agent nodes only:
Triage -> Investigator -> Evidence Collector -> Resolver -> Critic.
Retries loop Critic -> Resolver. Human approval and terminal status are controller
operations outside the agent graph; they are not additional agents.
"""
from __future__ import annotations

import uuid
from datetime import datetime, timezone
from typing import Any, TypedDict

from . import database as db
from .agents import AGENT_NAMES, CriticAgent, EvidenceCollectorAgent, InvestigatorAgent, ResolverAgent, TriageAgent
from .policy import MAX_ATTEMPTS


def now_iso() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat()


class GraphState(TypedDict):
    ctx: dict[str, Any]


class WorkflowController:
    """Orchestrate the five-agent workflow and route final status safely."""

    def __init__(self) -> None:
        self.triage_agent = TriageAgent()
        self.investigator_agent = InvestigatorAgent()
        self.evidence_collector_agent = EvidenceCollectorAgent()
        self.resolver_agent = ResolverAgent()
        self.critic_agent = CriticAgent()
        self._langgraph = None
        try:
            from langgraph.graph import END, START, StateGraph

            graph = StateGraph(GraphState)
            # Exactly five agent nodes. Controller decisions happen in conditional edges
            # or after graph completion; no Router/Approval/Finalizer agent exists.
            graph.add_node("triage_agent", self._triage_node)
            graph.add_node("investigator_agent", self._investigator_node)
            graph.add_node("evidence_collector_agent", self._evidence_collector_node)
            graph.add_node("resolver_agent", self._resolver_node)
            graph.add_node("critic_agent", self._critic_node)
            graph.add_edge(START, "triage_agent")
            graph.add_conditional_edges(
                "triage_agent", self._route_after_triage,
                {"investigator_agent": "investigator_agent", "end": END},
            )
            graph.add_edge("investigator_agent", "evidence_collector_agent")
            graph.add_conditional_edges(
                "evidence_collector_agent", self._route_after_evidence,
                {"resolver_agent": "resolver_agent", "end": END},
            )
            graph.add_edge("resolver_agent", "critic_agent")
            graph.add_conditional_edges(
                "critic_agent", self._route_after_critic,
                {"resolver_agent": "resolver_agent", "end": END},
            )
            self._langgraph = graph.compile()
            self.engine_name = "LangGraph StateGraph (5 agent nodes)"
            self.graph_agent_nodes = (
                "triage_agent", "investigator_agent", "evidence_collector_agent", "resolver_agent", "critic_agent"
            )
        except ImportError:
            self.engine_name = "Built-in bounded state machine (5 agents)"
            self.graph_agent_nodes = (
                "triage_agent", "investigator_agent", "evidence_collector_agent", "resolver_agent", "critic_agent"
            )

    def run(self, case_id: str, fault: str = "none", llm_mode: str = "offline", model: str = "llama3.2") -> dict[str, Any]:
        db.init_db()
        found = db.get_case_bundle(case_id)
        if not found:
            raise ValueError(f"Case {case_id!r} was not found.")
        case, shipment = found
        context: dict[str, Any] = {
            "run_id": str(uuid.uuid4()), "case_id": case["case_id"], "case": case, "shipment": shipment,
            "fault": fault, "llm_mode": llm_mode, "llm_model": model, "engine": self.engine_name,
            "started_at": now_iso(), "completed_at": None, "status": "IN_PROGRESS",
            "agent_sequence": list(AGENT_NAMES), "agent_status": {name: "PENDING" for name in AGENT_NAMES},
            "triage": {}, "plan": [], "bundle": [], "evidence_gaps": [], "critical_gap": False,
            "gap_ratio": 0.0, "evidence_quality": {}, "resolution": None, "attempt": 0,
            "critic_verdict": "PENDING", "critic_checks": [], "critic_notes": [], "rejected_attempts": [],
            "requires_human_review": False, "human_review_reasons": [], "trace": [],
            "summary": "", "summary_source": "deterministic", "llm_note": "",
            "investigator_source": "deterministic-policy-plan", "resolver_source": "deterministic-policy",
            "investigator_note": "", "resolver_note": "", "demo_fault_applied": None,
        }
        db.update_case_status(case_id, "IN_PROGRESS")
        try:
            if self._langgraph is not None:
                result = self._langgraph.invoke({"ctx": context})
                context = result["ctx"]
            else:
                context = self._run_fallback(context)
        except Exception as exc:  # fail closed, never pretend the workflow succeeded
            running = [name for name, status in context.get("agent_status", {}).items() if status == "RUNNING"]
            for name in running:
                context["agent_status"][name] = "FAILED"
            for name, status in context.get("agent_status", {}).items():
                if status == "PENDING":
                    context["agent_status"][name] = "SKIPPED"
            self._record(context, "Workflow Controller", "WORKFLOW_ERROR", "ERROR",
                         {"error": f"{type(exc).__name__}: {exc}", "failed_agent": running[-1] if running else None})
            context["status"] = "PENDING_APPROVAL"
            context["requires_human_review"] = True
            context["human_review_reasons"] = ["Workflow execution error; manual review is required. No automatic decision was made."]
        self._apply_terminal_status(context)
        context["summary"] = self._make_summary(context)
        db.save_investigation(context)
        return context

    @staticmethod
    def _record(ctx: dict[str, Any], agent: str, event_type: str, status: str, details: Any) -> None:
        event = db.record_audit_event(ctx["run_id"], ctx["case_id"], agent, event_type, status, details)
        ctx.setdefault("trace", []).append(event)

    def _run_agent(self, ctx: dict[str, Any], agent: Any, event_type: str, run_status: str = "SUCCESS") -> dict[str, Any]:
        name = agent.name
        ctx.setdefault("agent_status", {})[name] = "RUNNING"
        output = agent.run(ctx)
        ctx["agent_status"][name] = ctx.get("agent_status", {}).get(name, "COMPLETED")
        audit_status = run_status
        if name == "Evidence Collector Agent" and ctx.get("evidence_gaps"):
            audit_status = "WARN"
        if name == "Critic Agent" and ctx.get("critic_verdict") == "FAIL":
            audit_status = "ERROR"
        self._record(ctx, name, event_type, audit_status, output)
        return {"ctx": ctx}

    def _triage_node(self, state: GraphState) -> dict[str, Any]:
        return self._run_agent(state["ctx"], self.triage_agent, "TRIAGE_COMPLETE")

    def _investigator_node(self, state: GraphState) -> dict[str, Any]:
        return self._run_agent(state["ctx"], self.investigator_agent, "INVESTIGATION_PLAN_CREATED")

    def _evidence_collector_node(self, state: GraphState) -> dict[str, Any]:
        return self._run_agent(state["ctx"], self.evidence_collector_agent, "EVIDENCE_LEDGER_CREATED")

    def _resolver_node(self, state: GraphState) -> dict[str, Any]:
        return self._run_agent(state["ctx"], self.resolver_agent, "RESOLUTION_PROPOSED")

    def _critic_node(self, state: GraphState) -> dict[str, Any]:
        return self._run_agent(state["ctx"], self.critic_agent, "INDEPENDENT_VALIDATION")

    @staticmethod
    def _route_after_triage(state: GraphState) -> str:
        triage = state["ctx"].get("triage", {})
        return "investigator_agent" if triage.get("supported") and triage.get("classification_consistent", True) else "end"

    @staticmethod
    def _route_after_evidence(state: GraphState) -> str:
        return "end" if state["ctx"].get("critical_gap") else "resolver_agent"

    @staticmethod
    def _route_after_critic(state: GraphState) -> str:
        ctx = state["ctx"]
        if ctx.get("critic_verdict") == "FAIL" and int(ctx.get("attempt", 0)) < MAX_ATTEMPTS:
            return "resolver_agent"
        return "end"

    def _run_fallback(self, ctx: dict[str, Any]) -> dict[str, Any]:
        """Fallback follows the same five agents and routing rules as the LangGraph."""
        self._triage_node({"ctx": ctx})
        triage = ctx.get("triage", {})
        if not triage.get("supported") or not triage.get("classification_consistent", True):
            self._skip_agents(ctx, AGENT_NAMES[1:])
            return ctx
        self._investigator_node({"ctx": ctx})
        self._evidence_collector_node({"ctx": ctx})
        if ctx.get("critical_gap"):
            self._skip_agents(ctx, AGENT_NAMES[3:])
            return ctx
        while True:
            self._resolver_node({"ctx": ctx})
            self._critic_node({"ctx": ctx})
            if self._route_after_critic({"ctx": ctx}) == "resolver_agent":
                continue
            break
        return ctx

    @staticmethod
    def _skip_agents(ctx: dict[str, Any], names: tuple[str, ...] | list[str]) -> None:
        for name in names:
            if ctx.get("agent_status", {}).get(name) == "PENDING":
                ctx["agent_status"][name] = "SKIPPED"

    def _apply_terminal_status(self, ctx: dict[str, Any]) -> None:
        """Controller routing is policy logic, not a sixth agent."""
        for name, status in ctx.get("agent_status", {}).items():
            if status == "PENDING":
                ctx["agent_status"][name] = "SKIPPED"
        triage = ctx.get("triage", {})
        if not triage.get("supported") or not triage.get("classification_consistent", True):
            ctx["status"] = "PENDING_APPROVAL"
            ctx["requires_human_review"] = True
            ctx["human_review_reasons"] = ctx.get("human_review_reasons") or ["Exception classification requires human confirmation."]
        elif ctx.get("critical_gap"):
            ctx["status"] = "PENDING_APPROVAL"
            ctx["requires_human_review"] = True
        elif ctx.get("critic_verdict") == "FAIL":
            ctx["status"] = "PENDING_APPROVAL"
            ctx["requires_human_review"] = True
            ctx["human_review_reasons"] = list(ctx.get("human_review_reasons", [])) + [
                f"Critic validation still failed after {ctx.get('attempt', 0)} bounded attempt(s)."
            ]
        elif ctx.get("critic_verdict") != "PASS":
            ctx["status"] = "PENDING_APPROVAL"
            ctx["requires_human_review"] = True
            ctx["human_review_reasons"] = ctx.get("human_review_reasons") or ["The workflow ended without a validated proposal."]
        elif ctx.get("requires_human_review") or ctx.get("human_review_reasons"):
            ctx["status"] = "PENDING_APPROVAL"
            ctx["requires_human_review"] = True
        else:
            # This is an internal recommendation status only. No external action is executed.
            ctx["status"] = "AUTO_APPROVED"
            ctx["requires_human_review"] = False
        self._record(ctx, "Workflow Controller", "TERMINAL_ROUTING", "WARN" if ctx["status"] == "PENDING_APPROVAL" else "SUCCESS", {
            "status": ctx["status"], "requires_human_review": ctx["requires_human_review"],
            "reasons": ctx.get("human_review_reasons", []), "critic_verdict": ctx.get("critic_verdict", "PENDING"),
            "note": "Controller routing is not a separate agent. No payment, claim filing, or external action is executed.",
        })

    @staticmethod
    def _make_summary(ctx: dict[str, Any]) -> str:
        if not ctx.get("resolution"):
            return (
                f"{ctx.get('case_id')} was triaged as {ctx.get('triage', {}).get('priority', 'unclassified')} priority. "
                "Automated resolution was blocked because evidence or exception support was insufficient. "
                "Human review is required; no external action was executed."
            )
        r = ctx["resolution"]
        core = (
            f"{r.get('root_cause', 'Investigation completed')}. Proposed action: {r.get('action', 'N/A')}. "
            f"Estimated amount: ${float(r.get('amount', 0)):,.2f}. {r.get('rationale', '')} "
        )
        if ctx.get("critic_verdict") == "PASS":
            return core + "The proposal passed independent Critic checks; it remains a recommendation based on synthetic evidence. No payment, claim filing, or external action was executed."
        return core + "The proposal did not pass independent Critic validation and must not be treated as a validated outcome. Human review is required. No external action was executed."
