"""Run all seeded synthetic cases and export a compact evaluation CSV.

Example:
    python scripts/evaluate_cases.py --output evaluation_results.csv

This writes investigation and audit records to the configured local database.
Set FAIR_DB_PATH to a temporary or separate path for a non-invasive evaluation.
"""
from __future__ import annotations

import argparse
import csv
import json
import os
import sys
from pathlib import Path
from typing import Any

PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from fair import database as db  # noqa: E402
from fair.workflow import WorkflowController  # noqa: E402


def main() -> int:
    parser = argparse.ArgumentParser(description="Evaluate the ten synthetic F.A.I.R. scenarios.")
    parser.add_argument("--output", default="evaluation_results.csv", help="CSV output path (default: evaluation_results.csv)")
    parser.add_argument("--fault", choices=["none", "omitted_cap", "wrong_amount", "invalid_policy"], default="none",
                        help="Optional demonstration fault to inject in every Resolver's first attempt")
    args = parser.parse_args()

    db.init_db()
    controller = WorkflowController()
    cases = db.list_cases()
    rows: list[dict[str, Any]] = []
    for case in cases:
        result = controller.run(case["case_id"], fault=args.fault)
        resolution = result.get("resolution") or {}
        rows.append({
            "case_id": result["case_id"],
            "exception_type": result["case"].get("exception_type"),
            "severity": result["case"].get("severity"),
            "triage_priority": result.get("triage", {}).get("priority"),
            "status": result.get("status"),
            "action": resolution.get("action", "NO_AUTOMATED_RESOLUTION"),
            "amount": f"{float(resolution.get('amount', 0)):.2f}",
            "critic_verdict": result.get("critic_verdict"),
            "resolver_attempts": result.get("attempt", 0),
            "evidence_gaps": "|".join(result.get("evidence_gaps", [])),
            "human_review_required": bool(result.get("requires_human_review")),
            "agent_sequence": " > ".join(result.get("agent_sequence", [])),
            "agent_status_json": json.dumps(result.get("agent_status", {}), sort_keys=True),
        })

    out = Path(args.output).expanduser()
    if not out.is_absolute():
        out = Path.cwd() / out
    out.parent.mkdir(parents=True, exist_ok=True)
    with out.open("w", newline="", encoding="utf-8-sig") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0].keys()) if rows else [])
        if rows:
            writer.writeheader()
            writer.writerows(rows)
    pass_count = sum(1 for row in rows if row["critic_verdict"] == "PASS")
    pending_count = sum(1 for row in rows if row["status"] == "PENDING_APPROVAL")
    print(f"Evaluated {len(rows)} synthetic cases with {controller.engine_name}.")
    print(f"Critic PASS: {pass_count}/{len(rows)} | Human review: {pending_count}/{len(rows)}")
    print(f"CSV saved: {out}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
