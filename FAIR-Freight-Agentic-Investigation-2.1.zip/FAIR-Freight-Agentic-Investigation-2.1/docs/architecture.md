# F.A.I.R. 2.1 — Architecture and Agent Contracts

## Architectural constraint

F.A.I.R. has **exactly five agents**. The compiled LangGraph has five agent nodes; the built-in fallback invokes the same five agent classes. The controller manages routing, retry limits and human decisions, but is not an agent.

```mermaid
flowchart TD
    S([Start]) --> T[1. Triage Agent]
    T -->|Supported exception| I[2. Investigator Agent]
    T -->|Unsupported type| H[Controller: human review]
    I --> E[3. Evidence Collector Agent]
    E -->|Critical evidence missing| H
    E -->|Sufficient to proceed| R[4. Resolver Agent]
    R --> C[5. Critic Agent]
    C -->|FAIL and retry available| R
    C -->|PASS and no review trigger| A([Controller: validated recommendation])
    C -->|FAIL after retry / review trigger| H
    A --> Z([End])
    H --> Z
```

The two controller outcomes are workflow controls, **not additional agents**. The loop is bounded to two Resolver attempts total.

## The five agents

| Order | Agent | Input | Responsibilities | Output |
|---|---|---|---|---|
| 1 | Triage Agent | Case and shipment metadata | Cross-check the registered exception family against description signals; assign priority score; surface critical severity, strategic account and high-value flags. Conflicting or tied classification signals stop automation | `triage` with severity, priority, score, supported flag and rationale |
| 2 | Investigator Agent | Triage result, case, shipment | Build an exception-specific evidence plan; optionally reorder only the pre-approved tool list using Ollama | `plan`, source and planning note |
| 3 | Evidence Collector Agent | Plan and synthetic shipment fixture | Run read-only tools, retry failures, timestamp evidence, keep source and details, calculate evidence gaps and critical gaps | `bundle`, `evidence_quality`, gap flags |
| 4 | Resolver Agent | Case, shipment, evidence, prior Critic feedback | Compute an action and amount using deterministic policy; optionally accept a structured local-LLM *candidate* for Critic verification; never execute external actions | `resolution`, attempt count and review reasons |
| 5 | Critic Agent | Original case/shipment/evidence plus Resolver proposal | Independently recompute the expected action and amount; verify policy references, action allow-list, cap and arithmetic | `critic_verdict`, per-check details, revision feedback |

## Controller responsibilities (not agents)

- Start and stop the graph, preserve the ordered five-agent contract and implement the same route logic in the fallback engine.
- Route a `FAIL` Critic result back to Resolver only when a retry remains.
- Send critical evidence gaps, unsupported types, high-risk cases and unresolved Critic failures to human review.
- Apply the terminal status, persist the run, and append a `Workflow Controller` event to the audit trail.
- Never create a sixth Router, Human Approval, Finalizer or Narrative agent.

## Data and policy layer

- `fair/seed.py` holds ten explicitly synthetic scenarios spanning DAMAGE, DELAY, CUSTOMS_HOLD, MISROUTE and REFUSED_DELIVERY.
- `fair/evidence.py` holds the fixed read-only tool allow-list, evidence plans, retry behavior and evidence finding summaries.
- `fair/policy.py` contains deterministic resolution policy and an independently implemented Critic-side recomputation path.
- `fair/database.py` persists cases, shipments, investigation snapshots, decisions and a per-case SHA-256-linked audit chain in SQLite.
- `fair/llm.py` calls Ollama on localhost only, and only for Investigator tool ordering or Resolver candidates. A malformed result falls back safely. The Critic is the acceptance gate.

## Important runtime invariants

1. The source-of-record exception type selects a fixed evidence tool set; Triage cross-checks description signals and routes conflicting or tied classifications to a reviewer. An LLM cannot add, remove, or invent tools.
2. Critical evidence gaps prevent the Resolver and Critic from running automatically.
3. A Resolver candidate is not a decision until the Critic validates it.
4. Financial amounts and allowed actions are controlled by policy code, not by generated text.
5. A Critic failure may loop back to Resolver once only; a second failure escalates.
6. Reviewer identity in this prototype is a text field, not authenticated identity.
7. External actions are not executed. All data and evidence are synthetic.
8. The audit chain is tamper-evident, not a production immutable ledger; an administrator with direct database access could rewrite the database and recompute hashes.
