# F.A.I.R. 2.1 — Demo Script (5–7 minutes)

## 1. Open the application (30 seconds)

“F.A.I.R. stands for Freight Agentic Investigation & Resolution. It demonstrates a freight exception workflow with exactly five agents: Triage, Investigator, Evidence Collector, Resolver and Critic. The human-review control and terminal routing are controller logic, not additional agents. All sample records are synthetic.”

## 2. Show the Exception Queue (45 seconds)

Point out exception type, severity, current status, cargo value, filters and the case description. Explain that the Triage Agent produces a score and priority based on severity, cargo value and customer tier. The Investigator chooses a type-specific, allow-listed set of evidence tools.

## 3. Run a normal case (60 seconds)

Select `CASE-20260001` and keep demo fault injection at **None**. Show the five-agent workflow in the Investigation Console. Evidence is tagged by tool, source, retrieval status, attempts and finding. The Resolver applies the policy; the Critic independently verifies it.

Expected damage calculation: `$4,200 loss - $300 salvage + $180 freight refund - $250 deductible = $3,830`, within the effective cap. No payment is executed; the result is a recommendation.

## 4. Demonstrate self-correction (90 seconds)

Set **Omit liability cap**, then run `CASE-20260006`. On attempt one, the demo intentionally applies an incorrect uncapped amount. The Critic catches that the amount violates the independent policy recomputation/cap. The feedback is passed to Resolver for the single allowed revision. The corrected proposal is `$50,000`, and the high-value/strategic case still requires a human decision.

This is a controlled fault injection for demonstration, not a claim that a real LLM always makes this mistake.

## 5. Show safe escalation (45 seconds)

Run `CASE-20260009`, where the formal damage report is unavailable. Evidence Collector identifies a critical gap. Resolver and Critic are marked **Skipped safely**, and the workflow routes to review rather than inventing an amount.

Run `CASE-20260002` to show that missing weather verification cannot be used to justify a force-majeure denial.

## 6. Human approval and audit (60 seconds)

Open **Resolution & Approval**. A reviewer can approve a Critic-passed recommendation, reject it, request more evidence or make an explicitly recorded action override. The reviewer identity and note are saved. Open **Audit & Compliance** to verify event hashes and export JSON/CSV.

## 7. Close (20 seconds)

“The project combines a five-agent workflow, evidence provenance, deterministic policy enforcement, independent critique, bounded revision, human oversight, persistence and auditability. It is a proof of concept—not a production freight integration.”
