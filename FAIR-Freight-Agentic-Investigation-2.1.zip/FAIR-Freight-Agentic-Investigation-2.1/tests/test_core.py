from __future__ import annotations

import json

import pytest

from fair import database as db
from fair.evidence import build_plan, collect_evidence
from fair.policy import compute_resolution, critique
from fair.workflow import WorkflowController


@pytest.fixture(autouse=True)
def isolated_database(monkeypatch: pytest.MonkeyPatch, tmp_path):
    monkeypatch.setattr(db, "DB_PATH", tmp_path / "fair_test.sqlite3")
    db.init_db()
    yield


def test_exception_specific_plans_use_allowlisted_tools():
    assert {step["tool"] for step in build_plan("DAMAGE")} >= {"get_tracking", "get_pod", "get_damage_report"}
    assert {step["tool"] for step in build_plan("CUSTOMS_HOLD")} == {"get_customs_documents", "get_customs_status", "get_contract_terms"}
    with pytest.raises(ValueError):
        build_plan("UNKNOWN")


def test_damage_liability_calculation_is_deterministic_and_capped():
    case, ship = db.get_case_bundle("CASE-20260001")
    plan = build_plan(case["exception_type"])
    bundle = collect_evidence(plan, ship)
    result = compute_resolution(case, ship, bundle)
    assert result["action"] == "CARRIER_CLAIM"
    assert result["amount"] == pytest.approx(3830.00)
    assert result["amount"] <= result["effective_cap"]
    assert critique(case, ship, bundle, result)["verdict"] == "PASS"


def test_critic_catches_cap_omission_and_workflow_retries():
    result = WorkflowController().run("CASE-20260006", fault="omitted_cap")
    assert result["attempt"] == 2
    assert result["critic_verdict"] == "PASS"
    assert result["resolution"]["amount"] == pytest.approx(50000.00)
    assert result["rejected_attempts"]
    assert any("effective cap" in failed.lower() or "recomputation" in failed.lower() for failed in result["rejected_attempts"][0]["failed_checks"])
    assert result["status"] == "PENDING_APPROVAL"


def test_critical_missing_damage_report_escalates_without_auto_resolution():
    result = WorkflowController().run("CASE-20260009")
    assert result["status"] == "PENDING_APPROVAL"
    assert result["critical_gap"] is True
    assert result["resolution"] is None
    assert result["critic_verdict"] == "PENDING"
    assert "get_damage_report" in result["evidence_gaps"]


def test_weather_outage_does_not_trigger_unverified_force_majeure_denial():
    result = WorkflowController().run("CASE-20260002")
    assert result["resolution"]["action"] == "CUSTOMER_CREDIT"
    assert result["resolution"]["amount"] == pytest.approx(1000.00)
    assert result["status"] == "PENDING_APPROVAL"
    assert any("Weather was not independently verified" in item for item in result["human_review_reasons"])


def test_invalid_policy_reference_is_caught_then_corrected():
    result = WorkflowController().run("CASE-20260001", fault="invalid_policy")
    assert result["attempt"] == 2
    assert result["critic_verdict"] == "PASS"
    assert result["rejected_attempts"]
    assert any("Policy references exist" in failed for failed in result["rejected_attempts"][0]["failed_checks"])


def test_wrong_amount_fault_is_detected_and_corrected():
    result = WorkflowController().run("CASE-20260001", fault="wrong_amount")
    assert result["attempt"] == 2
    assert result["critic_verdict"] == "PASS"
    assert result["resolution"]["amount"] == pytest.approx(3830.00)
    assert any("Amount matches independent policy recomputation" in failed for failed in result["rejected_attempts"][0]["failed_checks"])


def test_hash_chain_verifies_and_detects_mutation():
    result = WorkflowController().run("CASE-20260001")
    ok, message = db.verify_audit_chain("CASE-20260001")
    assert ok, message
    with db.get_connection() as conn:
        row = conn.execute("SELECT id, details_json FROM audit_events WHERE case_id = ? ORDER BY id LIMIT 1", ("CASE-20260001",)).fetchone()
        changed = json.loads(row["details_json"])
        changed["tampered"] = True
        conn.execute("UPDATE audit_events SET details_json = ? WHERE id = ?", (json.dumps(changed, sort_keys=True, separators=(",", ":")), row["id"]))
    ok, message = db.verify_audit_chain("CASE-20260001")
    assert not ok
    assert "mismatch" in message.lower()


def test_human_decision_persists_and_is_audited():
    result = WorkflowController().run("CASE-20260006")
    assert result["status"] == "PENDING_APPROVAL"
    updated = db.apply_human_decision(result["run_id"], "APPROVE", "test_reviewer", "Reviewed evidence and cap calculation.")
    assert updated["status"] == "APPROVED"
    record = db.get_investigation(result["run_id"])
    assert record["status"] == "APPROVED"
    assert record["result"]["human_decisions"][-1]["reviewer"] == "test_reviewer"
    ok, message = db.verify_audit_chain("CASE-20260006")
    assert ok, message


def test_critically_corrected_proposal_can_be_approved():
    result = WorkflowController().run("CASE-20260006", fault="omitted_cap")
    # Fault injection is corrected after a single bounded retry, so Critic should pass.
    assert result["critic_verdict"] == "PASS"
    # A pending approval with a valid verdict is eligible for human approval.
    updated = db.apply_human_decision(result["run_id"], "APPROVE", "reviewer", "Reviewed.")
    assert updated["status"] == "APPROVED"


def test_approval_is_blocked_if_critic_verdict_is_not_pass():
    result = WorkflowController().run("CASE-20260006")
    with db.get_connection() as conn:
        row = conn.execute("SELECT result_json FROM investigations WHERE run_id = ?", (result["run_id"],)).fetchone()
        corrupted = json.loads(row["result_json"])
        corrupted["critic_verdict"] = "FAIL"
        conn.execute("UPDATE investigations SET result_json = ? WHERE run_id = ?", (json.dumps(corrupted), result["run_id"]))
    with pytest.raises(ValueError, match="Approval requires"):
        db.apply_human_decision(result["run_id"], "APPROVE", "reviewer", "Attempted approval without Critic pass.")


def test_reject_and_request_evidence_are_distinct_final_states():
    first = WorkflowController().run("CASE-20260006")
    rejected = db.apply_human_decision(first["run_id"], "REJECT", "reviewer", "Evidence does not satisfy local policy.")
    assert rejected["status"] == "REJECTED"
    second = WorkflowController().run("CASE-20260006")
    returned = db.apply_human_decision(second["run_id"], "REQUEST_EVIDENCE", "reviewer", "Attach updated inspection photos.")
    assert returned["status"] == "NEEDS_EVIDENCE"


def test_exactly_five_named_agents_and_controller_is_not_an_agent():
    from fair.agents import AGENT_NAMES

    expected = (
        "Triage Agent",
        "Investigator Agent",
        "Evidence Collector Agent",
        "Resolver Agent",
        "Critic Agent",
    )
    assert AGENT_NAMES == expected
    controller = WorkflowController()
    assert controller.graph_agent_nodes == ("triage_agent", "investigator_agent", "evidence_collector_agent", "resolver_agent", "critic_agent")
    result = controller.run("CASE-20260001")
    assert result["agent_sequence"] == list(expected)
    assert tuple(result["agent_status"].keys()) == expected
    names_in_trace = [event["agent"] for event in result["trace"] if event["agent"] in expected]
    assert list(dict.fromkeys(names_in_trace)) == list(expected)
    other_actors = {event["agent"] for event in result["trace"]} - set(expected)
    assert other_actors == {"Workflow Controller"}
    assert all(result["agent_status"][name] == "COMPLETED" for name in expected)


def test_critical_gap_skips_resolver_and_critic_safely():
    result = WorkflowController().run("CASE-20260009")
    assert result["status"] == "PENDING_APPROVAL"
    assert result["agent_status"]["Triage Agent"] == "COMPLETED"
    assert result["agent_status"]["Investigator Agent"] == "COMPLETED"
    assert result["agent_status"]["Evidence Collector Agent"] == "COMPLETED_WITH_GAPS"
    assert result["agent_status"]["Resolver Agent"] == "SKIPPED"
    assert result["agent_status"]["Critic Agent"] == "SKIPPED"
    assert result["attempt"] == 0


def test_retry_trace_is_only_resolver_and_critic_loop():
    result = WorkflowController().run("CASE-20260006", fault="omitted_cap")
    agent_trace = [event["agent"] for event in result["trace"] if event["agent"] != "Workflow Controller"]
    assert agent_trace == [
        "Triage Agent", "Investigator Agent", "Evidence Collector Agent",
        "Resolver Agent", "Critic Agent", "Resolver Agent", "Critic Agent",
    ]
    assert result["attempt"] == 2
    assert result["critic_verdict"] == "PASS"


def test_all_seeded_scenarios_complete_without_uncaught_exceptions():
    db.init_db()
    cases = db.list_cases()
    assert len(cases) == 10
    controller = WorkflowController()
    for case in cases:
        result = controller.run(case["case_id"])
        assert result["triage"]["supported"] is True
        assert result["status"] in {"AUTO_APPROVED", "PENDING_APPROVAL"}
        assert result["agent_sequence"] == [
            "Triage Agent", "Investigator Agent", "Evidence Collector Agent", "Resolver Agent", "Critic Agent"
        ]
        assert result["critic_verdict"] in {"PASS", "PENDING"}
        if result["critic_verdict"] == "PENDING":
            assert result["critical_gap"] is True
            assert result["requires_human_review"] is True


def test_langgraph_if_installed_contains_only_five_agent_nodes():
    controller = WorkflowController()
    if controller._langgraph is None:
        pytest.skip("LangGraph is not installed in this test environment; the five-agent fallback is tested instead.")
    graph_node_names = set(controller._langgraph.get_graph().nodes)
    graph_node_names.discard("__start__")
    graph_node_names.discard("__end__")
    assert graph_node_names == set(controller.graph_agent_nodes)


def test_ollama_unavailable_falls_back_without_adding_an_agent(monkeypatch: pytest.MonkeyPatch):
    from fair import llm

    def unavailable(*args, **kwargs):
        raise RuntimeError("synthetic Ollama outage used by test")

    monkeypatch.setattr(llm, "_generate", unavailable)
    result = WorkflowController().run("CASE-20260001", llm_mode="ollama", model="test-model")
    assert result["critic_verdict"] == "PASS"
    assert result["resolution"]["amount"] == pytest.approx(3830.0)
    assert result["agent_sequence"] == [
        "Triage Agent", "Investigator Agent", "Evidence Collector Agent", "Resolver Agent", "Critic Agent"
    ]
    assert result["investigator_source"] == "deterministic-fallback"
    assert result["resolver_source"] == "deterministic-fallback"


def test_triage_description_mismatch_routes_to_human_without_running_other_agents(monkeypatch: pytest.MonkeyPatch):
    original_get_case_bundle = db.get_case_bundle
    case, shipment = original_get_case_bundle("CASE-20260001")
    case = dict(case)
    case["description"] = "Shipment is at a customs hold because duty settlement is pending."
    monkeypatch.setattr(db, "get_case_bundle", lambda requested_id: (case, shipment) if requested_id == case["case_id"] else None)

    result = WorkflowController().run("CASE-20260001")
    assert result["status"] == "PENDING_APPROVAL"
    assert result["triage"]["inferred_type_hint"] == "CUSTOMS_HOLD"
    assert result["triage"]["classification_consistent"] is False
    assert result["resolution"] is None
    assert result["agent_status"]["Triage Agent"] == "COMPLETED_WITH_FLAGS"
    assert all(result["agent_status"][name] == "SKIPPED" for name in (
        "Investigator Agent", "Evidence Collector Agent", "Resolver Agent", "Critic Agent"
    ))
    assert any("Triage mismatch" in reason for reason in result["human_review_reasons"])


def test_triage_ambiguous_description_does_not_guess():
    from fair.agents import TriageAgent

    ctx = {
        "case": {"exception_type": "DAMAGE", "severity": "HIGH", "description": "Customs hold reported; damaged cargo also delayed by diversion."},
        "shipment": {"cargo_value": 25000, "customer_tier": "Standard"},
        "agent_status": {},
    }
    result = TriageAgent().run(ctx)
    assert result["classification_ambiguous"] is True
    assert result["classification_consistent"] is False
    assert ctx["requires_human_review"] is True
    assert any("Triage uncertainty" in reason for reason in ctx["human_review_reasons"])
