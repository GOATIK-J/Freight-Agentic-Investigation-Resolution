@echo off
setlocal
cd /d "%~dp0"
echo ========================================================
echo F.A.I.R. 2.1 - Five-agent setup and launch
echo ========================================================
where py >nul 2>nul
if errorlevel 1 (
  echo Python launcher 'py' was not found. Install Python 3.11+ and enable PATH.
  pause
  exit /b 1
)
if not exist .venv\Scripts\python.exe (
  echo Creating virtual environment...
  py -3 -m venv .venv
  if errorlevel 1 goto :error
)
call .venv\Scripts\activate.bat
python -m pip install --upgrade pip
if errorlevel 1 goto :error
pip install -r requirements.txt
if errorlevel 1 goto :error
echo Launching app at http://localhost:8501 ...
streamlit run app.py
if errorlevel 1 goto :error
goto :eof
:error
echo.
echo Setup or launch failed. Read the error above and the README.md troubleshooting section.
pause
exit /b 1
